 import { Platform } from 'react-native';
export const C = { maroon: '#6B1D33', maroonSoft: '#8A3248', cream: '#FBF5EC', blush: '#F5E6E3', sand: '#EFE4D3', ink: '#2A1A1E', mute: '#8B7B7E', line: '#E8D9D2', white: '#FFFFFF' };
export const serif = Platform.select({ ios: 'Georgia', android: 'serif', default: 'serif' });
export const rs = (n) => 'Rs. ' + String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ',');