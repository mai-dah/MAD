import React, { createContext, useContext, useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const Ctx = createContext(null);
export const useApp = () => useContext(Ctx);

export function AppProvider({ children }) {
  const [user, setUser] = useState(null);
  const [cart, setCart] = useState([]);
  const [lastOrder, setLastOrder] = useState(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const u = await AsyncStorage.getItem('session');
        const c = await AsyncStorage.getItem('cart');
        if (u) setUser(JSON.parse(u));
        if (c) setCart(JSON.parse(c));
      } catch (e) {}
      setReady(true);
    })();
  }, []);

  useEffect(() => {
    if (ready) AsyncStorage.setItem('cart', JSON.stringify(cart)).catch(() => {});
  }, [cart, ready]);

  const readUsers = async () => {
    try { return JSON.parse((await AsyncStorage.getItem('users')) || '[]'); } catch (e) { return []; }
  };
  const startSession = async (email) => {
    const name = email.split('@')[0].replace(/[._-]+/g, ' ');
    const u = { email, name: name.charAt(0).toUpperCase() + name.slice(1) };
    await AsyncStorage.setItem('session', JSON.stringify(u));
    setUser(u);
  };
  const signup = async (email, password) => {
    const users = await readUsers();
    if (users.find((x) => x.email === email)) return { ok: false, error: 'An account with this email already exists. Please sign in.' };
    await AsyncStorage.setItem('users', JSON.stringify([...users, { email, password }]));
    await startSession(email);
    return { ok: true };
  };
  const login = async (email, password) => {
    const users = await readUsers();
    const found = users.find((x) => x.email === email && x.password === password);
    if (!found) return { ok: false, error: 'Email or password is incorrect. New here? Create an account.' };
    await startSession(email);
    return { ok: true };
  };
  const logout = async () => { await AsyncStorage.removeItem('session').catch(() => {}); setUser(null); };

  const addToCart = (p) =>
    setCart((prev) => {
      const hit = prev.find((i) => i.id === p.id);
      if (hit) return prev.map((i) => (i.id === p.id ? { ...i, qty: i.qty + 1 } : i));
      return [...prev, { id: p.id, name: p.name, price: p.price, image: p.image, oldPrice: p.oldPrice, qty: 1 }];
    });
  const changeQty = (id, d) => setCart((prev) => prev.map((i) => (i.id === id ? { ...i, qty: Math.max(1, i.qty + d) } : i)));
  const removeItem = (id) => setCart((prev) => prev.filter((i) => i.id !== id));

  const subtotal = cart.reduce((s, i) => s + i.price * i.qty, 0);
  const discount = subtotal > 1200 ? Math.round(subtotal * 0.2) : 0; // 20% only when subtotal > Rs. 1,200
  const total = subtotal - discount;
  const count = cart.reduce((s, i) => s + i.qty, 0);

  const placeOrder = (details) => {
    setLastOrder({ id: 'MIRA-' + Date.now().toString().slice(-6), items: cart, subtotal, discount, total, details });
    setCart([]);
  };

  return (
    <Ctx.Provider value={{ user, cart, ready, subtotal, discount, total, count, lastOrder, signup, login, logout, addToCart, changeQty, removeItem, placeOrder }}>
      {children}
    </Ctx.Provider>
  );
}