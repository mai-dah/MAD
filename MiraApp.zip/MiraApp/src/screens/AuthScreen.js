import React, { useState } from 'react';
import { View, Text, ScrollView, TextInput, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C, rs } from '../theme';
import { useApp } from '../context';
import { Screen, Header, Title, Btn, ProductImage } from '../ui';
import { st } from './shared';

export function AuthScreen({ route, navigation }) {
  const pending = route.params?.pending;
  const { login, signup, addToCart } = useApp();
  const [mode, setMode] = useState('login');
  const [email, setEmail] = useState('');
  const [pw, setPw] = useState('');
  const [show, setShow] = useState(false);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const isLogin = mode === 'login';

  const submit = async () => {
    const e = email.trim().toLowerCase();
    if (!/^\S+@\S+\.\S+$/.test(e)) return setErr('Please enter a valid email address.');
    if (pw.length < 6) return setErr('Password must be at least 6 characters.');
    setBusy(true); setErr('');
    const r = await (isLogin ? login(e, pw) : signup(e, pw));
    setBusy(false);
    if (!r.ok) return setErr(r.error);
    if (pending) { addToCart(pending); navigation.navigate('Tabs', { screen: 'Cart' }); } else navigation.goBack();
  };
  return (
    <Screen>
      <Header back title="Account" />
      <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ paddingBottom: 30 }}>
        <Title eyebrow={isLogin ? 'Welcome back' : 'Join MIRA'} title={isLogin ? 'Good to see you.' : 'A place for you.'} sub={isLogin ? 'Sign in to continue. Your saved pieces are waiting.' : 'Create a free account. Your wishlist is waiting.'} />
        {pending && <View style={[st.note, { marginHorizontal: 20, alignItems: 'center' }]}><ProductImage item={pending} style={{ width: 44, height: 44, borderRadius: 8 }} iconSize={20} /><View style={{ marginLeft: 10, flex: 1 }}><Text style={{ fontSize: 10, color: C.maroonSoft, fontWeight: '700' }}>SAVED FOR YOUR NEXT STEP</Text><Text style={{ color: C.ink, fontWeight: '600' }}>{pending.name} · {rs(pending.price)}</Text></View></View>}
        <View style={{ paddingHorizontal: 20, marginTop: 14 }}>
          <Text style={st.lbl}>Email address</Text>
          <View style={st.input}><Ionicons name="mail-outline" size={18} color={C.mute} /><TextInput style={st.inp} value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" placeholder="you@example.com" placeholderTextColor={C.mute} /></View>
          <Text style={st.lbl}>{isLogin ? 'Password' : 'Create password'}</Text>
          <View style={st.input}><Ionicons name="lock-closed-outline" size={18} color={C.mute} /><TextInput style={st.inp} value={pw} onChangeText={setPw} secureTextEntry={!show} placeholder="At least 6 characters" placeholderTextColor={C.mute} />
            <TouchableOpacity onPress={() => setShow(!show)}><Ionicons name={show ? 'eye-off-outline' : 'eye-outline'} size={18} color={C.mute} /></TouchableOpacity></View>
          {!!err && <Text style={{ color: '#B3261E', fontSize: 12, marginTop: 10 }}>{err}</Text>}
          <Btn label={busy ? 'Please wait…' : isLogin ? (pending ? 'Sign in & resume Add to Cart' : 'Sign in') : (pending ? 'Create account & resume Add to Cart' : 'Create account')} onPress={submit} style={{ marginTop: 18 }} />
          <TouchableOpacity onPress={() => { setMode(isLogin ? 'signup' : 'login'); setErr(''); }} style={{ alignItems: 'center', marginTop: 16 }}>
            <Text style={{ color: C.mute }}>{isLogin ? 'New to MIRA? ' : 'Already have an account? '}<Text style={{ color: C.maroon, fontWeight: '800' }}>{isLogin ? 'Create account' : 'Sign in'}</Text></Text>
          </TouchableOpacity>
          <Text style={{ color: C.mute, fontSize: 11, textAlign: 'center', marginTop: 18 }}>Demo login. Your details are stored only on this device.</Text>
        </View>
      </ScrollView>
    </Screen>
  );
}