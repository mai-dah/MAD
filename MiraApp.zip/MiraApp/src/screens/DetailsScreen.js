import React from 'react';
import { View, Text, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C, serif } from '../theme';
import { useApp } from '../context';
import { Screen, Header, ProductImage, AddButton, PriceTag } from '../ui';
import { Note, st } from './shared';

export function DetailsScreen({ route }) {
  const { product: p } = route.params;
  const { user } = useApp();
  return (
    <Screen>
      <Header back title="Product details" />
      <ScrollView contentContainerStyle={{ paddingBottom: 30 }}>
        <ProductImage item={p} iconSize={90} style={{ aspectRatio: 0.9, marginHorizontal: 20, borderRadius: 18 }} />
        <View style={{ paddingHorizontal: 20, paddingTop: 16 }}>
          <Text style={st.eyebrow2}>{(p.cat || '').toUpperCase()}</Text>
          <Text style={{ fontFamily: serif, fontSize: 28, color: C.ink, marginTop: 4 }}>{p.name}</Text>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 6 }}>
            <PriceTag item={p} size={22} />
            {p.rating && <View style={{ flexDirection: 'row', alignItems: 'center' }}><Ionicons name="star" size={14} color="#C8921B" /><Text style={{ color: C.mute, marginLeft: 4 }}>{p.rating.rate} ({p.rating.count})</Text></View>}
          </View>
          {!user && <Note icon="lock-closed-outline" style={{ marginTop: 12 }}>Sign in to add this to your cart. Your pick will wait for you.</Note>}
          <Text style={{ fontFamily: serif, fontSize: 18, color: C.ink, marginTop: 18 }}>The details</Text>
          <Text style={{ color: '#5B4A4E', lineHeight: 22, marginTop: 6 }}>{p.desc}</Text>
          <AddButton large item={p} style={{ marginTop: 22 }} />
        </View>
      </ScrollView>
    </Screen>
  );
}