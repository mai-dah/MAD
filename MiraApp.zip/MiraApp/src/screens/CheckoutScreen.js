import React, { useEffect, useState, useRef } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { View, Text, ScrollView, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C, serif, rs } from '../theme';
import { useApp } from '../context';
import { Screen, Header, Title, Btn, ProductImage } from '../ui';
import { Note, Row, Field, st } from './shared';

export function CheckoutScreen({ navigation }) {
  const { cart, subtotal, discount, total, user, placeOrder } = useApp();
  const scrollRef = useRef(null);
  const [f, setF] = useState({ name: user?.name || '', email: user?.email || '', phone: '', address: '', city: '', postal: '', note: '' });
  const [pay, setPay] = useState('cod');
  const [errs, setErrs] = useState({});

  // refill phone/address from the last order, like other shopping apps
  useEffect(() => {
    AsyncStorage.getItem('delivery').then((s) => {
      if (!s) return;
      try { const d = JSON.parse(s); setF((p) => ({ ...p, name: d.name || p.name, phone: d.phone || '', address: d.address || '', city: d.city || '', postal: d.postal || '' })); } catch (e) {}
    }).catch(() => {});
  }, []);

  const set = (k) => (v) => { setF((p) => ({ ...p, [k]: v })); if (errs[k]) setErrs((p) => ({ ...p, [k]: '' })); };

  const validate = () => {
    const e = {};
    if (f.name.trim().length < 2) e.name = 'Please enter your full name.';
    if (!/^\S+@\S+\.\S+$/.test(f.email.trim())) e.email = 'Please enter a valid email address.';
    const digits = f.phone.replace(/\D/g, '');
    if (digits.length < 10 || digits.length > 13) e.phone = 'Please enter a valid phone number, for example 0300 1234567.';
    if (f.address.trim().length < 8) e.address = 'Please enter your full delivery address.';
    if (f.city.trim().length < 2) e.city = 'Please enter your city.';
    return e;
  };

  const place = () => {
    const e = validate();
    setErrs(e);
    if (Object.keys(e).length) { scrollRef.current?.scrollTo({ y: 0, animated: true }); return; }
    const details = {
      name: f.name.trim(), email: f.email.trim().toLowerCase(), phone: f.phone.trim(), address: f.address.trim(),
      city: f.city.trim(), postal: f.postal.trim(), note: f.note.trim(), payment: pay === 'cod' ? 'Cash on Delivery' : 'Card (demo)',
    };
    AsyncStorage.setItem('delivery', JSON.stringify(details)).catch(() => {});
    placeOrder(details);
    navigation.replace('Confirmed');
  };

  const PayOption = ({ id, title, sub, icon }) => (
    <TouchableOpacity activeOpacity={0.9} onPress={() => setPay(id)} style={[st.pay, pay === id && { borderColor: C.maroon, backgroundColor: C.blush }]}>
      <Ionicons name={icon} size={22} color={C.maroon} />
      <View style={{ flex: 1, marginLeft: 12 }}><Text style={{ color: C.ink, fontWeight: '700' }}>{title}</Text><Text style={{ color: C.mute, fontSize: 12 }}>{sub}</Text></View>
      <View style={[st.radio, pay === id && { borderColor: C.maroon }]}>{pay === id && <View style={st.radioDot} />}</View>
    </TouchableOpacity>
  );

  return (
    <Screen>
      <Header back title="Checkout" />
      <ScrollView ref={scrollRef} keyboardShouldPersistTaps="handled" automaticallyAdjustKeyboardInsets contentContainerStyle={{ paddingBottom: 30 }}>
        <Title eyebrow="Almost there" title={'All set, ' + (user?.name?.split(' ')[0] || 'friend') + '?'} sub="Tell us where to send your order, then review and place it." />

        <Text style={[st.sec, { marginTop: 0 }]}>Delivery details</Text>
        <View style={{ paddingHorizontal: 20 }}>
          <Field label="Full name" icon="person-outline" value={f.name} onChangeText={set('name')} placeholder="Your full name" autoCapitalize="words" error={errs.name} />
          <Field label="Email address" icon="mail-outline" value={f.email} onChangeText={set('email')} placeholder="you@example.com" autoCapitalize="none" keyboardType="email-address" error={errs.email} />
          <Field label="Phone number" icon="call-outline" value={f.phone} onChangeText={set('phone')} placeholder="0300 1234567" keyboardType="phone-pad" error={errs.phone} />
          <Field label="Delivery address" icon="location-outline" value={f.address} onChangeText={set('address')} placeholder="House / flat no., street, area" multiline error={errs.address} />
          <View style={{ flexDirection: 'row' }}>
            <Field style={{ flex: 1, marginRight: 10 }} label="City" icon="business-outline" value={f.city} onChangeText={set('city')} placeholder="City" autoCapitalize="words" error={errs.city} />
            <Field style={{ flex: 1 }} label="Postal code (optional)" icon="mail-open-outline" value={f.postal} onChangeText={set('postal')} placeholder="46000" keyboardType="number-pad" />
          </View>
          <Field label="Order note (optional)" icon="create-outline" value={f.note} onChangeText={set('note')} placeholder="Anything we should know?" />
        </View>

        <Text style={st.sec}>Payment method</Text>
        <View style={{ paddingHorizontal: 20 }}>
          <PayOption id="cod" icon="cash-outline" title="Cash on Delivery" sub="Pay when your order arrives" />
          <PayOption id="card" icon="card-outline" title="Card (demo)" sub="Demo only, no real payment is taken" />
        </View>

        <Text style={st.sec}>Your selected pieces</Text>
        {cart.map((i) => (
          <View key={i.id} style={st.cartRow}>
            <ProductImage item={i} style={{ width: 56, height: 56, borderRadius: 10 }} iconSize={22} />
            <View style={{ flex: 1, marginLeft: 12 }}><Text style={{ fontFamily: serif, fontSize: 15, color: C.ink }} numberOfLines={1}>{i.name}</Text><Text style={{ color: C.mute, fontSize: 12 }}>Quantity {i.qty}</Text></View>
            <Text style={{ fontWeight: '700', color: C.ink }}>{rs(i.price * i.qty)}</Text>
          </View>
        ))}
        <Note icon={discount ? 'checkmark-circle-outline' : 'pricetag-outline'} style={{ marginHorizontal: 20, marginTop: 8 }}>{discount ? '20% discount applied: you save ' + rs(discount) + '.' : 'Spend above Rs. 1,200 to get an automatic 20% discount.'}</Note>
        <View style={st.summary}>
          <Text style={{ fontFamily: serif, fontSize: 18, color: C.ink, marginBottom: 8 }}>Order summary</Text>
          <Row a="Subtotal" b={rs(subtotal)} />
          <Row a="Discount (20%)" b={discount ? '− ' + rs(discount) : 'Rs. 0'} green={!!discount} />
          <Row a="Delivery" b="Free" />
          <View style={st.hr} /><Row bold a="Final payable" b={rs(total)} />
        </View>
        <Btn label={'Place Order · ' + rs(total)} icon="checkmark" onPress={place} style={{ marginHorizontal: 20 }} />
        <Btn outline label="Continue shopping" onPress={() => navigation.navigate('Tabs', { screen: 'Home' })} style={{ marginHorizontal: 20, marginTop: 10 }} />
        <Text style={{ color: C.mute, fontSize: 11, textAlign: 'center', marginTop: 10 }}>Demo checkout. No real payment is taken.</Text>
      </ScrollView>
    </Screen>
  );
}