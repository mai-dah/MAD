import React from 'react';
import { View, Text, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C, serif, rs } from '../theme';
import { useApp } from '../context';
import { Screen, Btn, ProductImage } from '../ui';
import { Note, Row, st } from './shared';

export function ConfirmedScreen({ navigation }) {
  const { lastOrder: o } = useApp();
  if (!o) return null;
  return (
    <Screen>
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 30 }}>
        <View style={{ alignItems: 'center', marginTop: 20 }}>
          <View style={st.tick}><Ionicons name="checkmark" size={38} color={C.cream} /></View>
          <Text style={st.eyebrow2}>ORDER CONFIRMED · {o.id}</Text>
          <Text style={{ fontFamily: serif, fontSize: 30, color: C.ink, textAlign: 'center', marginTop: 6 }}>A lovely choice.</Text>
          <Text style={{ color: C.mute, textAlign: 'center', marginTop: 4 }}>Your demo order is placed. Thank you for shopping with MIRA.</Text>
        </View>
        <View style={[st.summary, { marginHorizontal: 0 }]}>
          {o.items.map((i) => <View key={i.id} style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 10 }}><ProductImage item={i} style={{ width: 46, height: 46, borderRadius: 8 }} iconSize={18} /><Text style={{ flex: 1, marginLeft: 10, color: C.ink }} numberOfLines={1}>{i.name} × {i.qty}</Text><Text style={{ fontWeight: '700' }}>{rs(i.price * i.qty)}</Text></View>)}
          <View style={st.hr} />
          <Row a="Subtotal" b={rs(o.subtotal)} /><Row a="Discount" b={o.discount ? '− ' + rs(o.discount) : 'Rs. 0'} green={!!o.discount} /><Row bold a="Demo payable" b={rs(o.total)} />
        </View>
        {!!o.details && (
          <View style={[st.summary, { marginHorizontal: 0, marginTop: 0 }]}>
            <Text style={{ fontFamily: serif, fontSize: 18, color: C.ink, marginBottom: 10 }}>Delivery details</Text>
            {[
              ['person-outline', o.details.name],
              ['location-outline', o.details.address + ', ' + o.details.city + (o.details.postal ? ' ' + o.details.postal : '')],
              ['call-outline', o.details.phone],
              ['mail-outline', o.details.email],
              [o.details.payment === 'Cash on Delivery' ? 'cash-outline' : 'card-outline', 'Payment: ' + o.details.payment],
              ...(o.details.note ? [['create-outline', 'Note: ' + o.details.note]] : []),
            ].map(([ic, txt], k) => (
              <View key={k} style={{ flexDirection: 'row', alignItems: 'flex-start', marginBottom: 8 }}>
                <Ionicons name={ic} size={16} color={C.maroon} style={{ marginTop: 2 }} />
                <Text style={{ flex: 1, marginLeft: 10, color: C.ink, lineHeight: 19 }}>{txt}</Text>
              </View>
            ))}
            <Note icon="mail-outline" style={{ marginTop: 4 }}>A confirmation for order {o.id} would be sent to {o.details.email}. This is a demo, so no email is actually sent.</Note>
          </View>
        )}
        <Btn label="Continue shopping" onPress={() => navigation.navigate('Tabs', { screen: 'Home' })} />
      </ScrollView>
    </Screen>
  );
}