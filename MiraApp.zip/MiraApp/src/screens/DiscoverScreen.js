import React, { useEffect, useState, useCallback } from 'react';
import { View, Text, ScrollView, FlatList, TextInput, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C } from '../theme';
import { API_URL, USD_TO_RS } from '../data';
import { Screen, Header, Title, Btn, Chip, ProductCard } from '../ui';
import { Note, st } from './shared';

export function DiscoverScreen({ route }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('All');

  const load = useCallback(async () => {
    setLoading(true); setError(false);
    try {
      const res = await fetch(API_URL);
      const data = await res.json();
      setItems(data.filter((d) => d.category !== 'electronics').map((d) => ({ id: 'api-' + d.id, name: d.title, price: Math.round(d.price * USD_TO_RS), desc: d.description, image: { uri: d.image }, rating: d.rating, cat: d.category })));
    } catch (e) { setError(true); }
    setLoading(false);
  }, []);
  useEffect(() => { load(); }, [load]);
  useEffect(() => { if (route.params?.q !== undefined) setQ(route.params.q); }, [route.params]);

  const cats = ['All', ...Array.from(new Set(items.map((i) => i.cat)))];
  const list = items.filter((i) => (cat === 'All' || i.cat === cat) && i.name.toLowerCase().includes(q.toLowerCase()));
  return (
    <Screen>
      <Header title="Discover" />
      {loading ? <View style={st.center}><ActivityIndicator size="large" color={C.maroon} /><Text style={{ color: C.mute, marginTop: 10 }}>Finding unexpected pieces…</Text></View>
        : error ? <View style={st.center}><Ionicons name="cloud-offline-outline" size={46} color={C.maroon} /><Text style={{ color: C.ink, marginVertical: 10 }}>We couldn't load products.</Text><Btn label="Try again" onPress={load} style={{ paddingHorizontal: 30 }} /></View>
        : <FlatList data={list} keyExtractor={(i) => i.id} numColumns={2} showsVerticalScrollIndicator={false}
            columnWrapperStyle={{ paddingHorizontal: 20, gap: 12, marginBottom: 12 }} contentContainerStyle={{ paddingBottom: 30 }}
            ListHeaderComponent={<View>
              <Title eyebrow="The shop beyond" title="Unexpected finds." sub={'A curated collection from our partner store API · ' + list.length + ' products'} />
              <View style={[st.search, { marginTop: 0 }]}><Ionicons name="search" size={18} color={C.mute} /><TextInput style={{ flex: 1, marginLeft: 8, color: C.ink }} placeholder="Search products" placeholderTextColor={C.mute} value={q} onChangeText={setQ} /></View>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 14 }}>
                {cats.map((c) => <Chip key={c} label={c === 'All' ? 'All' : c.replace(/^\w/, (x) => x.toUpperCase())} active={cat === c} onPress={() => setCat(c)} />)}
              </ScrollView>
              <Note icon="information-circle-outline" style={{ marginHorizontal: 20, marginBottom: 14 }}>Prices converted from USD at Rs. {USD_TO_RS} per dollar.</Note>
            </View>}
            ListEmptyComponent={<Text style={{ textAlign: 'center', color: C.mute, marginTop: 30 }}>No products match your search.</Text>}
            renderItem={({ item }) => <ProductCard item={item} />} />}
    </Screen>
  );
}