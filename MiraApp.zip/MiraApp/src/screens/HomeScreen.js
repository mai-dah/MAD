import React, { useState } from 'react';
import { View, Text, ScrollView, TextInput, TouchableOpacity, StyleSheet, ImageBackground } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C, serif } from '../theme';
import { PRODUCTS } from '../data';
import { Screen, Header, ProductImage, Marquee, AddButton, PriceTag } from '../ui';
import { IMG } from '../images';
import { OFFER, Note, st } from './shared';

export function HomeScreen({ navigation }) {
  const [q, setQ] = useState('');
  const cats = [
    { t: 'Accessories', r: 'Accessories', cover: 'm1' },
    { t: 'Clothes', r: 'Clothes', cover: 'cm1' },
    { t: 'Makeup', r: 'Makeup', cover: 'mk1' },
  ];
  const picks = PRODUCTS.filter((p) => p.id === 'w1' || p.id === 'mk1');
  return (
    <Screen>
      <Header />
      <Marquee text={OFFER} />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 30 }}>
        <View style={st.search}>
          <Ionicons name="search" size={18} color={C.mute} />
          <TextInput style={{ flex: 1, marginLeft: 8, color: C.ink }} placeholder="Find your next favourite" placeholderTextColor={C.mute} value={q} onChangeText={setQ} returnKeyType="search"
            onSubmitEditing={() => { navigation.navigate('Discover', { q }); setQ(''); }} />
        </View>
        <TouchableOpacity activeOpacity={0.9} onPress={() => navigation.navigate('Category', { cat: 'clothes' })}>
          <ImageBackground source={{ uri: IMG.hero }} style={[st.hero, { backgroundColor: C.maroon }]} imageStyle={{ borderRadius: 20 }}>
            <View style={[StyleSheet.absoluteFill, { backgroundColor: 'rgba(60,10,25,0.55)' }]} />
            <Text style={st.heroSmall}>NEW SEASON</Text>
            <Text style={st.heroT}>Made for your everyday.</Text>
            <Text style={{ color: '#F1D9DE', marginTop: 16, fontWeight: '700' }}>Explore Clothes  →</Text>
          </ImageBackground>
        </TouchableOpacity>
        <Note icon="pricetag-outline" style={{ marginHorizontal: 20 }}>20% off above Rs. 1,200. Automatically applied at checkout.</Note>

        <Text style={st.sec}>Choose your style</Text>
        <View style={{ flexDirection: 'row', paddingHorizontal: 20 }}>
          {cats.map((c, i) => (
            <TouchableOpacity key={c.t} style={[st.catTile, i < 2 && { marginRight: 10 }]} onPress={() => navigation.navigate(c.r === 'Makeup' ? 'Products' : 'Category', c.r === 'Makeup' ? { cat: 'makeup', title: 'Makeup', eyebrow: 'Makeup', head: 'Your daily colour.', sub: 'Expressive colour. Real MIRA comfort. Everyday formulas, thoughtfully chosen.' } : { cat: c.t.toLowerCase() })}>
              <ProductImage item={PRODUCTS.find((x) => x.id === c.cover)} style={{ width: '88%', aspectRatio: 1, borderRadius: 12 }} />
              <Text style={st.catT}>{c.t}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <Text style={st.sec}>Small joys, daily</Text>
        <View style={{ flexDirection: 'row', paddingHorizontal: 20 }}>
          {picks.map((p, i) => (
            <View key={p.id} style={{ flex: 1, marginRight: i === 0 ? 12 : 0 }}>
              <TouchableOpacity activeOpacity={0.9} onPress={() => navigation.navigate('Details', { product: p })}>
                <ProductImage item={p} style={{ width: '100%', aspectRatio: 0.85, borderRadius: 14 }} />
                <Text style={st.pn}>{p.name}</Text><PriceTag item={p} />
              </TouchableOpacity>
              <AddButton item={p} style={{ marginTop: 6 }} />
            </View>
          ))}
        </View>

        <TouchableOpacity style={st.beyond} onPress={() => navigation.navigate('Discover')}>
          <View style={{ flex: 1 }}>
            <Text style={{ fontFamily: serif, fontSize: 18, color: C.ink }}>Beyond the familiar</Text>
            <Text style={{ color: C.mute, fontSize: 12, marginTop: 3 }}>Explore Discover, a live collection from our partner store.</Text>
          </View>
          <Ionicons name="arrow-forward-circle" size={30} color={C.maroon} />
        </TouchableOpacity>
      </ScrollView>
    </Screen>
  );
}