import React, { useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { View, Text, ScrollView, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C, serif } from '../theme';
import { useApp } from '../context';
import { Screen, Header, Title, Btn } from '../ui';
import { Field, st } from './shared';

export function FeedbackScreen({ navigation }) {
  const { user } = useApp();
  const [rating, setRating] = useState(0);
  const [msg, setMsg] = useState('');
  const [err, setErr] = useState('');
  const [sent, setSent] = useState(false);

  const submit = async () => {
    if (!rating) { setErr('Please choose a star rating.'); return; }
    try {
      const old = JSON.parse((await AsyncStorage.getItem('mira_feedback')) || '[]');
      old.push({ rating, msg: msg.trim(), email: user?.email, date: new Date().toISOString() });
      await AsyncStorage.setItem('mira_feedback', JSON.stringify(old));
    } catch (e) {}
    setSent(true);
  };

  if (sent) {
    return (
      <Screen><Header back title="Send feedback" />
        <View style={st.center}>
          <View style={st.emptyIcon}><Ionicons name="heart-outline" size={60} color={C.maroon} /></View>
          <Text style={{ fontFamily: serif, fontSize: 26, color: C.ink, marginTop: 20 }}>Thank you.</Text>
          <Text style={{ color: C.mute, textAlign: 'center', marginVertical: 8 }}>Your feedback helps us make MIRA better.</Text>
          <Btn label="Back to account" onPress={() => navigation.goBack()} style={{ paddingHorizontal: 30, marginTop: 10 }} />
        </View>
      </Screen>
    );
  }

  return (
    <Screen><Header back title="Send feedback" />
      <ScrollView contentContainerStyle={{ paddingBottom: 30 }} keyboardShouldPersistTaps="handled">
        <Title eyebrow="We're listening" title="How are we doing?" sub="Rate your experience and tell us what you think." />
        <View style={{ paddingHorizontal: 20 }}>
          <Text style={st.lbl}>Your rating</Text>
          <View style={{ flexDirection: 'row' }}>
            {[1, 2, 3, 4, 5].map((n) => (
              <TouchableOpacity key={n} onPress={() => { setRating(n); setErr(''); }} style={{ marginRight: 8 }}>
                <Ionicons name={n <= rating ? 'star' : 'star-outline'} size={36} color="#C8921B" />
              </TouchableOpacity>
            ))}
          </View>
          {!!err && <Text style={{ color: '#B3261E', fontSize: 11, marginTop: 4 }}>{err}</Text>}
          <Field label="Your message (optional)" icon="chatbubble-outline" placeholder="What did you like? What can we improve?" multiline value={msg} onChangeText={setMsg} />
          <Btn label="Submit feedback" onPress={submit} style={{ marginTop: 24 }} />
        </View>
      </ScrollView>
    </Screen>
  );
}