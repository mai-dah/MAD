import React from 'react';
import { View, Text, ScrollView, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C, serif, rs } from '../theme';
import { useApp } from '../context';
import { Screen, Header, Title, Btn, ProductImage, PriceTag } from '../ui';
import { Note, Row, st } from './shared';

export function CartScreen({ navigation }) {
  const { cart, subtotal, discount, total, changeQty, removeItem, user } = useApp();
  if (!cart.length) {
    return (
      <Screen><Header title="Your cart" />
        <View style={st.center}>
          <View style={st.emptyIcon}><Ionicons name="bag-handle-outline" size={64} color={C.maroon} /></View>
          <Text style={{ fontFamily: serif, fontSize: 26, color: C.ink, marginTop: 20 }}>Room for discovery.</Text>
          <Text style={{ color: C.mute, textAlign: 'center', marginTop: 8, marginBottom: 20 }}>Your cart is taking a breather. Explore Clothes, Accessories and Makeup.</Text>
          <Btn label="Start shopping" onPress={() => navigation.navigate('Home')} style={{ paddingHorizontal: 40 }} />
        </View>
      </Screen>
    );
  }
  const go = () => (user ? navigation.navigate('Checkout') : navigation.navigate('Auth'));
  return (
    <Screen>
      <Header title="Your cart" />
      <ScrollView contentContainerStyle={{ paddingBottom: 30 }}>
        <Title eyebrow="Your picks" title="Your everyday edit." />
        <Note icon="pricetag-outline" style={{ marginHorizontal: 20, marginBottom: 12 }}>{discount > 0 ? 'You qualify for 20% off! Applied at checkout.' : 'Add ' + rs(1201 - subtotal) + ' more to unlock 20% off.'}</Note>
        {cart.map((i) => (
          <View key={i.id} style={st.cartRow}>
            <ProductImage item={i} style={{ width: 70, height: 70, borderRadius: 10 }} iconSize={26} />
            <View style={{ flex: 1, marginLeft: 12 }}>
              <Text style={{ fontFamily: serif, fontSize: 15, color: C.ink }} numberOfLines={1}>{i.name}</Text>
              <PriceTag item={i} reserve={false} />
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <TouchableOpacity style={st.qBtn} onPress={() => changeQty(i.id, -1)}><Ionicons name="remove" size={16} color={C.maroon} /></TouchableOpacity>
                <Text style={{ marginHorizontal: 12, fontWeight: '700' }}>{i.qty}</Text>
                <TouchableOpacity style={st.qBtn} onPress={() => changeQty(i.id, 1)}><Ionicons name="add" size={16} color={C.maroon} /></TouchableOpacity>
              </View>
            </View>
            <TouchableOpacity onPress={() => removeItem(i.id)} style={{ padding: 6 }}><Ionicons name="trash-outline" size={20} color={C.mute} /></TouchableOpacity>
          </View>
        ))}
        <View style={st.summary}>
          <Text style={{ fontFamily: serif, fontSize: 18, color: C.ink, marginBottom: 8 }}>Order summary</Text>
          <Row a="Subtotal" b={rs(subtotal)} />
          <Row a="Promo · 20% off" b={discount ? '− ' + rs(discount) : 'Rs. 0'} green={!!discount} />
          <Row a="Delivery" b="Free" />
          <View style={st.hr} /><Row bold a="Final payable" b={rs(total)} />
        </View>
        <Btn label={'Checkout · ' + rs(total)} icon="arrow-forward" onPress={go} style={{ marginHorizontal: 20 }} />
        {!user && <Text style={{ color: C.mute, fontSize: 11, textAlign: 'center', marginTop: 8 }}>You'll be asked to sign in before checkout.</Text>}
      </ScrollView>
    </Screen>
  );
}