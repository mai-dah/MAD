import React from 'react';
import { View, Text, TextInput, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C, serif } from '../theme';

export const OFFER = '20% OFF on Shopping Above Rs. 1,200 — Available Till 20 October';
export const Note = ({ icon, children, style }) => (
  <View style={[st.note, style]}><Ionicons name={icon} size={16} color={C.maroon} style={{ marginRight: 8 }} /><Text style={{ flex: 1, color: C.maroon, fontSize: 12, lineHeight: 17 }}>{children}</Text></View>
);
export const Row = ({ a, b, bold, green }) => (
  <View style={st.row}><Text style={[st.rowA, bold && { fontWeight: '800', color: C.ink }]}>{a}</Text><Text style={[st.rowB, bold && { fontSize: 18, color: C.maroon }, green && { color: '#2E7D4F' }]}>{b}</Text></View>
);

export const Field = ({ label, icon, error, style, ...props }) => (
  <View style={style}>
    <Text style={st.lbl}>{label}</Text>
    <View style={[st.input, props.multiline && { height: 82, alignItems: 'flex-start', paddingTop: 13 }, !!error && { borderColor: '#B3261E' }]}>
      <Ionicons name={icon} size={18} color={C.mute} />
      <TextInput style={[st.inp, props.multiline && { textAlignVertical: 'top', paddingTop: 0 }]} placeholderTextColor={C.mute} {...props} />
    </View>
    {!!error && <Text style={{ color: '#B3261E', fontSize: 11, marginTop: 4 }}>{error}</Text>}
  </View>
);

export const st = StyleSheet.create({
  note: { flexDirection: 'row', backgroundColor: C.blush, borderRadius: 12, padding: 12, borderWidth: 1, borderColor: C.line, marginTop: 10 },
  row: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 5 },
  rowA: { color: C.mute, fontSize: 14 }, rowB: { color: C.ink, fontWeight: '700', fontSize: 14 },
  hr: { height: 1, backgroundColor: C.line, marginVertical: 8 },
  logo: { width: 58, height: 58, borderRadius: 29, borderWidth: 1.5, borderColor: C.cream, alignItems: 'center', justifyContent: 'center' },
  offer: { marginTop: 22, borderWidth: 1, borderColor: '#E7C9CF', borderRadius: 20, paddingHorizontal: 18, paddingVertical: 8, backgroundColor: 'rgba(255,255,255,0.1)' },
  splashIcon: { width: 56, height: 56, borderRadius: 28, backgroundColor: 'rgba(255,255,255,0.12)', alignItems: 'center', justifyContent: 'center', marginHorizontal: 6 },
  splashCard: { backgroundColor: C.cream, borderTopLeftRadius: 28, borderTopRightRadius: 28, padding: 24, paddingBottom: 40 },
  search: { flexDirection: 'row', alignItems: 'center', backgroundColor: C.white, borderWidth: 1, borderColor: C.line, borderRadius: 12, marginHorizontal: 20, marginVertical: 14, paddingHorizontal: 12, height: 44 },
  hero: { marginHorizontal: 20, backgroundColor: C.maroon, borderRadius: 20, padding: 22, minHeight: 170, justifyContent: 'flex-end', overflow: 'hidden' },
  heroSmall: { color: '#E7C9CF', fontSize: 10, letterSpacing: 3, fontWeight: '700' },
  heroT: { fontFamily: serif, color: C.cream, fontSize: 30, lineHeight: 36, marginTop: 6, width: '75%' },
  sec: { fontFamily: serif, fontSize: 20, color: C.ink, paddingHorizontal: 20, marginTop: 22, marginBottom: 12 },
  catTile: { flex: 1, backgroundColor: C.white, borderRadius: 16, borderWidth: 1, borderColor: C.line, alignItems: 'center', paddingVertical: 16 },
  catIcon: { width: 60, height: 60, borderRadius: 30, alignItems: 'center', justifyContent: 'center' },
  catT: { marginTop: 8, fontWeight: '700', color: C.ink, fontSize: 13 },
  pn: { fontFamily: serif, fontSize: 15, color: C.ink, marginTop: 8 }, pp: { color: C.maroon, fontWeight: '800', marginTop: 2 },
  beyond: { flexDirection: 'row', alignItems: 'center', backgroundColor: C.sand, borderRadius: 16, padding: 16, margin: 20 },
  seg: { flexDirection: 'row', marginHorizontal: 20, backgroundColor: C.sand, borderRadius: 12, padding: 4 },
  segB: { flex: 1, alignItems: 'center', paddingVertical: 10, borderRadius: 9 },
  subImg: { height: 170, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 30 },
  eyebrow2: { fontSize: 10, letterSpacing: 2, color: C.maroonSoft, fontWeight: '700', marginTop: 14 },
  lbl: { color: C.ink, fontWeight: '600', fontSize: 12, marginTop: 14, marginBottom: 6 },
  input: { flexDirection: 'row', alignItems: 'center', backgroundColor: C.white, borderWidth: 1, borderColor: C.line, borderRadius: 12, paddingHorizontal: 12, height: 48 },
  inp: { flex: 1, marginHorizontal: 8, color: C.ink },
  cartRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: C.white, borderRadius: 14, borderWidth: 1, borderColor: C.line, padding: 10, marginHorizontal: 20, marginBottom: 10 },
  qBtn: { width: 28, height: 28, borderRadius: 14, borderWidth: 1, borderColor: C.maroon, alignItems: 'center', justifyContent: 'center' },
  pay: { flexDirection: 'row', alignItems: 'center', backgroundColor: C.white, borderWidth: 1, borderColor: C.line, borderRadius: 14, padding: 14, marginBottom: 10 },
  radio: { width: 20, height: 20, borderRadius: 10, borderWidth: 2, borderColor: C.line, alignItems: 'center', justifyContent: 'center' },
  radioDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: C.maroon },
  summary: { backgroundColor: C.white, borderRadius: 16, borderWidth: 1, borderColor: C.line, padding: 16, margin: 20 },
  emptyIcon: { width: 130, height: 130, borderRadius: 65, backgroundColor: C.blush, alignItems: 'center', justifyContent: 'center' },
  tick: { width: 74, height: 74, borderRadius: 37, backgroundColor: C.maroon, alignItems: 'center', justifyContent: 'center' },
  avatar: { width: 54, height: 54, borderRadius: 27, backgroundColor: C.maroon, alignItems: 'center', justifyContent: 'center' },
  acRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: C.white, borderRadius: 14, borderWidth: 1, borderColor: C.line, padding: 14, marginHorizontal: 20, marginTop: 10 },
});