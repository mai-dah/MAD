import React from 'react';
import { FlatList } from 'react-native';
import { PRODUCTS } from '../data';
import { Screen, Header, Title, ProductCard } from '../ui';

export function ProductsScreen({ route }) {
  const { cat, g, s, title, eyebrow, head, sub } = route.params;
  const list = PRODUCTS.filter((p) => p.cat === cat && (!s || (p.g === g && p.s === s)));
  return (
    <Screen>
      <Header back title={title} />
      <FlatList data={list} keyExtractor={(i) => i.id} numColumns={2} showsVerticalScrollIndicator={false}
        columnWrapperStyle={{ paddingHorizontal: 20, gap: 12, marginBottom: 12 }} contentContainerStyle={{ paddingBottom: 30 }}
        ListHeaderComponent={<Title eyebrow={eyebrow} title={head} sub={sub + ' · ' + list.length + ' products'} />}
        renderItem={({ item }) => <ProductCard item={item} />} />
    </Screen>
  );
}