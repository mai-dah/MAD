import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C, serif } from '../theme';
import { SUBS, PRODUCTS } from '../data';
import { Screen, Header, Title, ProductImage } from '../ui';
import { st } from './shared';

export function CategoryScreen({ route, navigation }) {
  const { cat, parent } = route.params; // parent = Luxury / Pret (opens the Stitched / Unstitched level)
  const cfg = SUBS[cat];
  const [g, setG] = useState('male');
  const gender = parent ? 'female' : g;
  const list = parent ? parent.children : cfg[g];
  const head = parent ? parent.head : cfg.head[g];
  const genderLabel = gender === 'male' ? 'Male' : 'Female';
  const coverOf = (sub) => PRODUCTS.find((x) => x.cat === cat && x.g === gender && (sub.children ? sub.children.some((c) => c.key === x.s) : x.s === sub.key));
  const open = (sub) => {
    if (sub.children) { navigation.navigate('Category', { cat, parent: sub }); return; }
    navigation.navigate('Products', {
      cat, g: gender, s: sub.key, title: parent ? parent.label + ' ' + sub.label : sub.label,
      eyebrow: cfg.title + ' · ' + genderLabel + (parent ? ' · ' + parent.label : ''),
      head: parent ? parent.label + ' ' + sub.label : sub.label, sub: sub.blurb,
    });
  };
  return (
    <Screen>
      <Header back title={parent ? parent.label : cfg.title} />
      <ScrollView contentContainerStyle={{ paddingBottom: 30 }}>
        <Title eyebrow={parent ? cfg.title + ' · Female' : 'The ' + cfg.title.toLowerCase() + ' edit'} title={head[0]} sub={head[1]} />
        {!parent && (
          <View style={st.seg}>
            {['male', 'female'].map((k) => (
              <TouchableOpacity key={k} style={[st.segB, g === k && { backgroundColor: C.maroon }]} onPress={() => setG(k)}>
                <Text style={{ color: g === k ? C.cream : C.ink, fontWeight: '700' }}>{k === 'male' ? 'Male' : 'Female'}</Text>
              </TouchableOpacity>
            ))}
          </View>
        )}
        {list.map((sub) => (
          <TouchableOpacity key={sub.key} activeOpacity={0.9} style={{ marginHorizontal: 20, marginTop: 16 }} onPress={() => open(sub)}>
            <ProductImage item={coverOf(sub)} style={{ width: '100%', aspectRatio: 1.3, borderRadius: 18 }} iconSize={64} />
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 8 }}>
              <View style={{ flex: 1, paddingRight: 10 }}><Text style={{ fontFamily: serif, fontSize: 20, color: C.ink }}>{sub.label}</Text><Text style={{ color: C.mute, fontSize: 12 }}>{sub.blurb}</Text></View>
              <Ionicons name="arrow-forward-circle-outline" size={26} color={C.maroon} />
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </Screen>
  );
}