import React, { useEffect } from 'react';
import { View, Text, StyleSheet, ImageBackground } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C, serif } from '../theme';
import { Btn, Logo } from '../ui';
import { IMG } from '../images';
import { st } from './shared';

export function SplashScreen({ navigation }) {
  useEffect(() => { const t = setTimeout(() => navigation.replace('Tabs'), 2500); return () => clearTimeout(t); }, []);
  return (
    <ImageBackground source={{ uri: IMG.splash }} style={{ flex: 1, backgroundColor: C.maroon, justifyContent: 'space-between' }}>
      <View style={[StyleSheet.absoluteFill, { backgroundColor: 'rgba(107,29,51,0.80)' }]} />
      <View style={{ alignItems: 'center', marginTop: 90 }}>
        <Logo size={110} />
        <Text style={{ fontFamily: serif, fontSize: 52, color: C.cream, letterSpacing: 10, marginTop: 16 }}>MIRA</Text>
        <Text style={{ color: '#E7C9CF', fontSize: 11, letterSpacing: 4, marginTop: 6 }}>THE EVERYDAY EDIT</Text>
        <View style={st.offer}><Text style={{ color: C.cream, fontWeight: '700', letterSpacing: 1 }}>20% OFF — Limited Stock!</Text></View>
        <View style={{ flexDirection: 'row', marginTop: 34 }}>
          {['shirt-outline', 'bag-handle-outline', 'diamond-outline', 'brush-outline'].map((i) => (
            <View key={i} style={st.splashIcon}><Ionicons name={i} size={26} color={C.cream} /></View>
          ))}
        </View>
      </View>
      <View style={st.splashCard}>
        <Text style={{ fontFamily: serif, fontSize: 26, color: C.ink }}>A little more you.</Text>
        <Text style={{ color: C.mute, marginTop: 4, marginBottom: 14 }}>Accessories, clothes and makeup for every day.</Text>
        <Btn label="Explore MIRA" icon="arrow-forward" onPress={() => navigation.replace('Tabs')} />
      </View>
    </ImageBackground>
  );
}