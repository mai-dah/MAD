import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C, serif, rs } from '../theme';
import { useApp } from '../context';
import { Screen, Header, Title, Btn } from '../ui';
import { Note, st } from './shared';

export function AccountScreen({ navigation }) {
  const { user, logout, count, lastOrder } = useApp();
  if (!user) {
    return (
      <Screen><Header title="Account" />
        <View style={st.center}>
          <View style={st.emptyIcon}><Ionicons name="person-outline" size={60} color={C.maroon} /></View>
          <Text style={{ fontFamily: serif, fontSize: 26, color: C.ink, marginTop: 20 }}>Hello, guest.</Text>
          <Text style={{ color: C.mute, textAlign: 'center', marginVertical: 8 }}>Sign in to add to cart and check out.</Text>
          <Btn label="Sign in / Create account" onPress={() => navigation.navigate('Auth')} style={{ paddingHorizontal: 30, marginTop: 10 }} />
        </View>
      </Screen>
    );
  }
  const initials = user.name.split(' ').map((w) => w[0]).join('').slice(0, 2).toUpperCase();
  const rows = [
    { i: 'bag-outline', t: 'My cart', v: count + ' item(s)', go: () => navigation.navigate('Cart') },
    { i: 'compass-outline', t: 'Discover new pieces', v: '', go: () => navigation.navigate('Discover') },
    { i: 'pricetag-outline', t: 'Offer', v: '20% off above Rs. 1,200', go: () => navigation.navigate('Home') },
    { i: 'chatbubble-ellipses-outline', t: 'Send feedback', v: 'Tell us what you think', go: () => navigation.navigate('Feedback') },
    ...(lastOrder ? [{ i: 'receipt-outline', t: 'Last order', v: lastOrder.id + ' · ' + rs(lastOrder.total), go: () => navigation.navigate('Confirmed') }] : []),
  ];
  return (
    <Screen><Header title="Your account" />
      <ScrollView contentContainerStyle={{ paddingBottom: 30 }}>
        <Title eyebrow="Welcome back" title={'Hello, ' + user.name.split(' ')[0] + '.'} />
        <View style={[st.summary, { flexDirection: 'row', alignItems: 'center', marginTop: 0 }]}>
          <View style={st.avatar}><Text style={{ color: C.cream, fontWeight: '800', fontSize: 18 }}>{initials}</Text></View>
          <View style={{ marginLeft: 12 }}><Text style={{ fontFamily: serif, fontSize: 18, color: C.ink }}>{user.name}</Text><Text style={{ color: C.mute }}>{user.email}</Text></View>
        </View>
        <Note icon="checkmark-circle-outline" style={{ marginHorizontal: 20 }}>Signed in. Demo session saved on this device.</Note>
        {rows.map((r) => (
          <TouchableOpacity key={r.t} style={st.acRow} onPress={r.go}>
            <Ionicons name={r.i} size={20} color={C.maroon} /><View style={{ flex: 1, marginLeft: 12 }}><Text style={{ color: C.ink, fontWeight: '600' }}>{r.t}</Text>{!!r.v && <Text style={{ color: C.mute, fontSize: 12 }}>{r.v}</Text>}</View><Ionicons name="chevron-forward" size={18} color={C.mute} />
          </TouchableOpacity>
        ))}
        <Btn outline label="Sign out" icon="log-out-outline" onPress={() => Alert.alert('Sign out', 'Are you sure?', [{ text: 'Cancel' }, { text: 'Sign out', onPress: logout }])} style={{ marginHorizontal: 20, marginTop: 20 }} />
      </ScrollView>
    </Screen>
  );
}