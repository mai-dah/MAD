const u = (id) => `https://images.unsplash.com/${id}?auto=format&fit=crop&w=800&q=80`;

export const IMG = {
  splash: u('photo-1483985988355-763728e1935b'),
  hero: u('photo-1490481651871-ab68de25d43d'),
  accessories: u('photo-1524592094714-0f0654e20314'),
  clothes: u('photo-1445205170230-053b83016050'),
  makeup: u('photo-1522335789203-aabd1fc54bc9'),
  // photos for each subcategory (cards in the same list take turns using them)
  sub: {
    'accessories-male-wallets': [u('photo-1627123424574-724758594e93')],
    'accessories-male-watches': [u('photo-1523275335684-37898b6baf30'), u('photo-1524592094714-0f0654e20314')],
    'accessories-female-jewellery': [u('photo-1605100804763-247f67b3557e'), u('photo-1515562141207-7a88fb7ce338')],
    'accessories-female-purses': [u('photo-1584917865442-de89df76afd3'), u('photo-1548036328-c9fa89d128fa')],
    'clothes-male-stitched': [u('photo-1593030761757-71fae45fa0e7'), u('photo-1617137968427-85924c800a22')],
    'clothes-male-unstitched': [u('photo-1558769132-cb1aea458c5e'), u('photo-1520006403909-838d6b92c22e')],
    'clothes-female-stitched': [u('photo-1583391733956-3750e0ff4e8b'), u('photo-1610030469983-98e550d6193c')],
    'clothes-female-unstitched': [u('photo-1558769132-cb1aea458c5e'), u('photo-1520006403909-838d6b92c22e')],
    'makeup-x-x': [u('photo-1522335789203-aabd1fc54bc9'), u('photo-1586495777744-4413f21062fa'), u('photo-1596462502278-27bfdc403348'), u('photo-1512496015851-a90fb38ba796')],
  },
};