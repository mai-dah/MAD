// Categories and subcategories (exactly as in the project document)
export const SUBS = {
  accessories: {
    title: 'Accessories',
    head: { male: ['Finishing touches.', 'The men-wish. Much-loved essentials, carefully picked.'], female: ['The little details.', 'The female edit. Graceful pieces for ordinary and extraordinary days.'] },
    male: [
      { key: 'wallets', label: 'Purses/Wallets', blurb: 'Pocket-sized essentials', icon: 'wallet-outline', tint: '#E9D3BE' },
      { key: 'watches', label: 'Watches', blurb: 'Time, well spent', icon: 'watch-outline', tint: '#DDD6CC' },
    ],
    female: [
      { key: 'jewellery', label: 'Jewellery', blurb: 'A little luminosity', icon: 'diamond-outline', tint: '#F0DDB8' },
      { key: 'purses', label: 'Purses', blurb: 'Carry your world', icon: 'bag-handle-outline', tint: '#E8C9C6' },
    ],
  },
  clothes: {
    title: 'Clothes',
    head: { male: ['Ease, in every thread.', 'The male wardrobe. Ready to wear, or ready to make your own.'], female: ['Wear your own story.', 'The female wardrobe. Dressed to wear, or styled to your own.'] },
    male: [
      { key: 'stitched', label: 'Stitched', blurb: 'Ready to wear', icon: 'shirt-outline', tint: '#E4D8C8' },
      { key: 'unstitched', label: 'Unstitched', blurb: 'Cut your cloth', icon: 'layers-outline', tint: '#D8D0C0' },
      { key: 'western', label: 'Western', blurb: 'Shirts, jackets and relaxed trousers', icon: 'glasses-outline', tint: '#DCD3C4' },
    ],
    // Female has only two categories: Luxury and Pret. Each one opens into Stitched and Unstitched.
    female: [
      {
        key: 'luxury', label: 'Luxury', blurb: 'Embroidered formals and occasion wear', icon: 'sparkles-outline', tint: '#EAD3C4',
        head: ['Luxury, defined.', 'Statement formals with hand-finished embroidery, made for the moments that matter.'],
        children: [
          { key: 'luxury-stitched', label: 'Stitched', blurb: 'Ready for the occasion', icon: 'shirt-outline', tint: '#EBCFCF' },
          { key: 'luxury-unstitched', label: 'Unstitched', blurb: 'Luxury fabrics, to style', icon: 'layers-outline', tint: '#E3C3C0' },
        ],
      },
      {
        key: 'pret', label: 'Pret', blurb: 'Everyday ready-to-wear', icon: 'flower-outline', tint: '#E6CFCB',
        head: ['Pret, made easy.', 'Effortless everyday pieces, easy to style and comfortable to wear.'],
        children: [
          { key: 'pret-stitched', label: 'Stitched', blurb: 'Dressed and ready', icon: 'shirt-outline', tint: '#EBCFCF' },
          { key: 'pret-unstitched', label: 'Unstitched', blurb: 'Fabrics, to style', icon: 'layers-outline', tint: '#E3C3C0' },
        ],
      },
    ],
  },
};

// Every product is a simple object: cat = category, g = gender, s = subcategory
// image: require(...) = picture saved in assets/images
export const PRODUCTS = [

  // Accessories - Male - Wallets
  { id: 'w1', cat: 'accessories', g: 'male', s: 'wallets', name: 'Tan Zip-Around Wallet', price: 1000, desc: 'A textured tan leather wallet with a secure zip, made for your daily essentials.', image: require('../assets/images/male-wallet-1.jpg') },
  { id: 'w2', cat: 'accessories', g: 'male', s: 'wallets', name: 'Chestnut Leather Bifold', price: 1800, desc: 'A glossy chestnut bifold with neat contrast stitching and room for cards and notes.', image: require('../assets/images/male-wallet-2.jpg') },
  { id: 'w3', cat: 'accessories', g: 'male', s: 'wallets', name: 'Camel Long Wallet', price: 1500, desc: 'A slim camel-coloured long wallet with a soft, worn-in finish.', image: require('../assets/images/male-wallet-3.jpg') },
  { id: 'w4', cat: 'accessories', g: 'male', s: 'wallets', name: 'Black & Tan Stripe Wallet', price: 2100, desc: 'A black leather wallet with a tan stripe and an embossed crest.', image: require('../assets/images/male-wallet-4.jpg') },

  // Accessories - Male - Watches
  { id: 'm1', cat: 'accessories', g: 'male', s: 'watches', name: 'Brown Leather Chronograph', price: 4500, desc: 'A silver case with a white dial and a rich brown leather strap.', image: require('../assets/images/male-watch-1.jpg') },
  { id: 'm2', cat: 'accessories', g: 'male', s: 'watches', name: 'Rose Gold Mesh Watch', price: 5200, desc: 'A black dial set in a rose gold case with a fine mesh strap.', image: require('../assets/images/male-watch-2.jpg') },
  { id: 'm3', cat: 'accessories', g: 'male', s: 'watches', name: 'Silver Steel Black Dial', price: 3600, desc: 'A sleek steel bracelet watch with a bold black dial.', image: require('../assets/images/male-watch-3.jpg') },
  { id: 'm4', cat: 'accessories', g: 'male', s: 'watches', name: 'Sport Chronograph Watch', price: 4200, desc: 'A sporty chronograph with a black bezel and a dark brown strap.', image: require('../assets/images/male-watch-4.jpg') },

  // Accessories - Female - Jewellery
  { id: 'j1', cat: 'accessories', g: 'female', s: 'jewellery', name: 'Gold Chain Bracelet Set', price: 2200, desc: 'A stack of five gold-tone bracelets in different chain styles.', image: require('../assets/images/female-jewellery-1.jpg') },
  { id: 'j2', cat: 'accessories', g: 'female', s: 'jewellery', name: 'Crystal Drop Earrings', price: 1800, desc: 'Sparkling silver-tone chandelier earrings with a crystal drop.', image: require('../assets/images/female-jewellery-2.jpg') },
  { id: 'j3', cat: 'accessories', g: 'female', s: 'jewellery', name: 'Rose Gold Solitaire Pendant', price: 2600, desc: 'A rose gold snake chain with a sparkling solitaire pendant.', image: require('../assets/images/female-jewellery-3.jpg') },
  { id: 'j4', cat: 'accessories', g: 'female', s: 'jewellery', name: 'Colourful Oxidised Set', price: 1500, desc: 'A pendant and jhumka earring set with bright enamel colours.', image: require('../assets/images/female-jewellery-4.jpg') },

  // Accessories - Female - Purses
  { id: 'f1', cat: 'accessories', g: 'female', s: 'purses', name: 'Floral Embroidered Jute Tote', price: 2800, desc: 'A beige jute tote with hand-stitched wildflower embroidery.', image: require('../assets/images/female-bag-1.jpg') },
  { id: 'f2', cat: 'accessories', g: 'female', s: 'purses', name: 'White Quilted Chain Bag', price: 1900, desc: 'A white quilted bag with a gold zip and a gold chain strap.', image: require('../assets/images/female-bag-2.jpg') },
  { id: 'f3', cat: 'accessories', g: 'female', s: 'purses', name: 'Tan Crossbody Bag', price: 3400, desc: 'A tan handbag with a front pocket and a wide shoulder strap.', image: require('../assets/images/female-bag-3.jpg') },
  { id: 'f4', cat: 'accessories', g: 'female', s: 'purses', name: 'Black 3-Piece Bag Set', price: 4200, desc: 'A black handbag set with a crossbody bag and a matching pouch.', image: require('../assets/images/female-bag-4.jpg') },

  // Clothes - Male - Stitched
  { id: 'cm1', cat: 'clothes', g: 'male', s: 'stitched', name: 'Cream Shalwar Kameez', price: 3600, desc: 'A classic cream shalwar kameez with a collared placket and a relaxed, easy fit, made for gatherings and everyday wear.', image: require('../assets/images/male-stitched-5.jpg') },
  { id: 'cm2', cat: 'clothes', g: 'male', s: 'stitched', name: 'Ash Grey Kurta Shalwar', price: 3200, desc: 'A clean ash grey kurta shalwar with a band collar and tailored fit.', image: require('../assets/images/male-stitched-2.jpg') },
  { id: 'cm3', cat: 'clothes', g: 'male', s: 'stitched', name: 'Navy Blue Shalwar Kameez', price: 3400, desc: 'A deep navy shalwar kameez, ready for gatherings.', image: require('../assets/images/male-stitched-3.jpg') },
  { id: 'cm4', cat: 'clothes', g: 'male', s: 'stitched', name: 'Slate Grey Collar Kurta', price: 3000, desc: 'A slate grey collared kurta with matching shalwar.', image: require('../assets/images/male-stitched-4.jpg') },

  // Clothes - Male - Unstitched
  { id: 'cu1', cat: 'clothes', g: 'male', s: 'unstitched', name: 'Chocolate Brown Superfine', price: 3300, desc: 'A rich chocolate brown superfine fabric with a smooth hand.', image: require('../assets/images/male-unstitched-1.jpg') },
  { id: 'cu2', cat: 'clothes', g: 'male', s: 'unstitched', name: 'Charcoal Black Merino Wool', price: 4800, desc: 'A deep charcoal merino wool blend with a soft drape.', image: require('../assets/images/male-unstitched-2.jpg') },
  { id: 'cu3', cat: 'clothes', g: 'male', s: 'unstitched', name: 'Steel Grey Linen Blend', price: 2800, desc: 'A steel grey linen-look fabric with a fine woven texture.', image: require('../assets/images/male-unstitched-3.jpg') },
  { id: 'cu4', cat: 'clothes', g: 'male', s: 'unstitched', name: 'Dark Olive Suiting', price: 2600, desc: 'A dark olive suiting fabric, ready to be stitched.', image: require('../assets/images/male-unstitched-4.jpg') },

  // Clothes - Male - Western
  { id: 'wm1', cat: 'clothes', g: 'male', s: 'western', name: 'Chocolate Linen Shirt & Ivory Trousers', price: 3400, desc: 'A relaxed chocolate linen shirt with pearl buttons, styled with pleated ivory trousers.', image: require('../assets/images/male-western-1.jpg') },
  { id: 'wm2', cat: 'clothes', g: 'male', s: 'western', name: 'Forest Green Overshirt & Charcoal Denim', price: 4200, desc: 'An oversized forest green overshirt over a white tee, with relaxed charcoal denim.', image: require('../assets/images/male-western-2.jpg') },
  { id: 'wm3', cat: 'clothes', g: 'male', s: 'western', name: 'Olive Shirt & Stone Trousers', price: 3200, desc: 'An olive linen-look shirt over a white tee, with easy stone-coloured trousers.', image: require('../assets/images/male-western-3.jpg') },
  { id: 'wm4', cat: 'clothes', g: 'male', s: 'western', name: 'Camel Utility Jacket & Black Trousers', price: 5600, desc: 'A soft camel jacket with flap pockets, a white roll-neck and tailored black trousers.', image: require('../assets/images/male-western-4.jpg') },

  // Clothes - Female - Luxury - Stitched
  { id: 'ls1', cat: 'clothes', g: 'female', s: 'luxury-stitched', name: 'Seafoam Cutwork Luxury Formal', price: 14800, desc: 'A seafoam formal with floral embroidery, a delicate cutwork hem and a blush pink net dupatta.', image: require('../assets/images/female-luxury-stitched-1.jpg') },
  { id: 'ls2', cat: 'clothes', g: 'female', s: 'luxury-stitched', name: 'Lilac Cutwork Luxury Suit', price: 16500, desc: 'A soft lilac suit with white cutwork, pearl tassels and a richly embroidered organza dupatta.', image: require('../assets/images/female-luxury-stitched-2.jpg') },
  { id: 'ls3', cat: 'clothes', g: 'female', s: 'luxury-stitched', name: 'Maroon Jacquard Luxury Suit', price: 13800, desc: 'A deep maroon jacquard suit with gold embroidery, pearl drops and a printed chiffon dupatta.', image: require('../assets/images/female-luxury-stitched-3.jpg') },
  { id: 'ls4', cat: 'clothes', g: 'female', s: 'luxury-stitched', name: 'Blush Sequin Net Formal', price: 17900, desc: 'A blush net formal with silver sequin work and pearls, finished with a matching net dupatta.', image: require('../assets/images/female-luxury-stitched-4.jpg') },

  // Clothes - Female - Luxury - Unstitched
  { id: 'lu1', cat: 'clothes', g: 'female', s: 'luxury-unstitched', name: 'Dusty Rose Chiffon Formal', price: 12500, desc: 'A dusty rose chiffon with fine floral thread work, pearl details and a sheer embroidered dupatta.', image: require('../assets/images/female-luxury-unstitched-1.jpg') },
  { id: 'lu2', cat: 'clothes', g: 'female', s: 'luxury-unstitched', name: 'Lilac Ombre Embroidered 3-Piece', price: 9800, desc: 'A lilac to plum ombre with lace and embroidery, paired with a soft matching dupatta.', image: require('../assets/images/female-luxury-unstitched-2.jpg') },
  { id: 'lu3', cat: 'clothes', g: 'female', s: 'luxury-unstitched', name: 'Powder Blue Floral Lace 3-Piece', price: 11200, desc: 'A powder blue floral lace suit with a beaded neckline and a delicate lace dupatta.', image: require('../assets/images/female-luxury-unstitched-3.jpg') },
  { id: 'lu4', cat: 'clothes', g: 'female', s: 'luxury-unstitched', name: 'Ivory Lily-Print Embroidered Suit', price: 8600, desc: 'An ivory suit with bright hand-painted lily prints, light embroidery and a striped dupatta.', image: require('../assets/images/female-luxury-unstitched-4.jpg') },

  // Clothes - Female - Pret - Stitched
  { id: 'cf1', cat: 'clothes', g: 'female', s: 'pret-stitched', name: 'Ivory Cotton Kurta Set', price: 2800, desc: 'A soft ivory cotton kurta with side slits and matching trousers, light and easy for every day.', image: require('../assets/images/female-pret-stitched-1.jpg') },
  { id: 'cf2', cat: 'clothes', g: 'female', s: 'pret-stitched', name: 'Sand Embroidered Kurta', price: 3500, desc: 'A sand-toned kurta with colourful thread embroidery on the neckline, sleeves and hem.', image: require('../assets/images/female-pret-stitched-2.jpg') },
  { id: 'cf3', cat: 'clothes', g: 'female', s: 'pret-stitched', name: 'Chocolate Bow Kurta Set', price: 3200, desc: 'A chocolate brown kurta with bow embroidery and matching palazzo.', image: require('../assets/images/female-pret-stitched-3.jpg') },
  { id: 'cf4', cat: 'clothes', g: 'female', s: 'pret-stitched', name: 'Plum Embroidered Three-Piece', price: 5200, desc: 'A rich plum three-piece with gold border embroidery, wide palazzo and a sequin net dupatta.', image: require('../assets/images/female-pret-stitched-4.jpg') },

  // Clothes - Female - Pret - Unstitched
  { id: 'cg1', cat: 'clothes', g: 'female', s: 'pret-unstitched', name: 'Ivory & Red Silk-Linen', price: 5400, desc: 'An ivory silk-linen suit with red and gold embroidery and a red dupatta.', image: require('../assets/images/female-pret-unstitched-1.jpg') },
  { id: 'cg2', cat: 'clothes', g: 'female', s: 'pret-unstitched', name: 'Mint & Mustard Lace Suit', price: 4600, desc: 'A mint and mustard duo with lace detailing and matching dupattas.', image: require('../assets/images/female-pret-unstitched-2.jpg') },
  { id: 'cg3', cat: 'clothes', g: 'female', s: 'pret-unstitched', name: 'Sage Chikankari Suit', price: 4200, desc: 'A sage green chikankari suit with white embroidered trousers.', image: require('../assets/images/female-pret-unstitched-3.jpg') },
  { id: 'cg4', cat: 'clothes', g: 'female', s: 'pret-unstitched', name: 'Slate Blue Block Print', price: 3600, desc: 'A pure cotton block print in slate blue with a cream dupatta.', image: require('../assets/images/female-pret-unstitched-4.jpg') },

  // Makeup
  { id: 'mk1', cat: 'makeup', name: 'Creamy Concealer', price: 1800, desc: 'A creamy, blendable concealer in a natural beige shade.', image: require('../assets/images/makeup-1.jpg') },
  { id: 'mk2', cat: 'makeup', name: 'Vinyl Black Eyeliner', price: 1500, desc: 'A precise liquid eyeliner pen with a glossy black finish.', image: require('../assets/images/makeup-2.jpg') },
  { id: 'mk3', cat: 'makeup', name: 'Sky High Mascara', price: 1200, desc: 'A lengthening mascara in a rose gold tube for dramatic lashes.', image: require('../assets/images/makeup-3.jpg') },
  { id: 'mk4', cat: 'makeup', name: 'Everyday Makeup Kit', price: 4500, desc: 'A full set with foundation, blush, brush, mascara and a palette.', image: require('../assets/images/makeup-4.jpg') },
  { id: 'mk5', cat: 'makeup', name: 'Mauve Eyeshadow Palette', price: 2200, desc: 'A pink palette of mauve, berry and shimmer shades.', image: require('../assets/images/makeup-5.jpg') },
  { id: 'mk6', cat: 'makeup', name: 'Nude Rose Eyeshadow Palette', price: 2400, desc: 'A rose gold palette with nude, matte and glitter shades.', image: require('../assets/images/makeup-6.jpg') },
  { id: 'mk7', cat: 'makeup', name: 'Matte Lipstick Collection', price: 1600, desc: 'A row of matte lipsticks from soft pink to deep brick red.', image: require('../assets/images/makeup-7.jpg') },
  { id: 'mk8', cat: 'makeup', name: 'Nude Lip Collection', price: 2600, desc: 'Lipsticks, glosses and a lip balm in rosy nude shades.', image: require('../assets/images/makeup-8.jpg') },
];

export const API_URL = 'https://fakestoreapi.com/products';
export const USD_TO_RS = 280;

// 20% sale on some products: oldPrice = original price (shown cut), price = discounted price
const SALE = ['wm4', 'ls3', 'lu1', 'w2', 'm1', 'm4', 'j1', 'j3', 'f2', 'f4', 'cm2', 'cu2', 'cf2', 'cg1', 'cg3', 'mk1', 'mk4', 'mk5'];
PRODUCTS.forEach((p) => {
  if (SALE.includes(p.id)) {
    p.oldPrice = p.price;
    p.price = Math.round(p.price * 0.8);
  }
});