import React, { useEffect, useRef, useState } from 'react';
import { View, Text, Image, TouchableOpacity, Animated, Easing, Dimensions, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { C, serif, rs } from './theme';
import { useApp } from './context';

export const Screen = ({ children }) => <SafeAreaView style={{ flex: 1, backgroundColor: C.cream }} edges={['top']}>{children}</SafeAreaView>;
export const Logo = ({ size = 60 }) => (
  <Image source={require('../assets/logo.png')} style={{ width: size, height: size }} resizeMode="contain" />
);
export function Header({ title, back }) {
  const nav = useNavigation();
  const { count } = useApp();
  return (
    <View style={s.header}>
      {back ? (
        <TouchableOpacity style={s.hBtn} onPress={() => nav.goBack()}><Ionicons name="arrow-back" size={20} color={C.ink} /></TouchableOpacity>
      ) : <View style={s.hBtn} />}
   {title ? <Text style={s.hTitle}>{title.toUpperCase()}</Text> : <Logo size={38} />}
      <TouchableOpacity style={s.hBtn} onPress={() => nav.navigate('Tabs', { screen: 'Cart' })}>
        <Ionicons name="bag-outline" size={20} color={C.ink} />
        {count > 0 && <View style={s.badge}><Text style={s.badgeT}>{count}</Text></View>}
      </TouchableOpacity>
    </View>
  );
}

export const Title = ({ eyebrow, title, sub }) => (
  <View style={{ paddingHorizontal: 20, paddingTop: 8, paddingBottom: 14 }}>
    {!!eyebrow && <Text style={s.eyebrow}>{eyebrow.toUpperCase()}</Text>}
    <Text style={s.title}>{title}</Text>
    {!!sub && <Text style={s.sub}>{sub}</Text>}
  </View>
);

export const Btn = ({ label, onPress, outline, small, icon, style }) => (
  <TouchableOpacity activeOpacity={0.85} onPress={onPress}
    style={[s.btn, small && { paddingVertical: 9 }, outline ? s.btnO : s.btnF, style]}>
    {!!icon && <Ionicons name={icon} size={15} color={outline ? C.maroon : C.cream} style={{ marginRight: 6 }} />}
    <Text style={[s.btnT, { color: outline ? C.maroon : C.cream }, small && { fontSize: 12 }]}>{label}</Text>
  </TouchableOpacity>
);

export const Chip = ({ label, active, onPress }) => (
  <TouchableOpacity onPress={onPress} style={[s.chip, active && { backgroundColor: C.maroon, borderColor: C.maroon }]}>
    <Text style={{ color: active ? C.cream : C.maroon, fontSize: 12, fontWeight: '600' }}>{label}</Text>
  </TouchableOpacity>
);

// Shows the product picture. contain = the full picture is always visible, never cropped.
export function ProductImage({ item, style, iconSize = 44 }) {
  const [bad, setBad] = useState(false);
  if (!item.image || bad) {
    return (
      <View style={[{ backgroundColor: C.sand, alignItems: 'center', justifyContent: 'center' }, style]}>
        <Ionicons name="bag-outline" size={iconSize} color={C.maroon} />
      </View>
    );
  }
  return (
    <View style={[{ backgroundColor: C.white, padding: 4 }, style]}>
      <Image source={item.image} style={{ width: '100%', height: '100%' }} resizeMode="contain" onError={() => setBad(true)} />
    </View>
  );
}

export function useAdd() {
  const nav = useNavigation();
  const { user, addToCart } = useApp();
  return (p) => {
    if (!user) { nav.navigate('Auth', { pending: p }); return; } // login check
    addToCart(p); // no popup: the button itself changes to a quantity stepper
  };
}

// Add to Cart button. Before adding: normal button. After adding: it turns dark
// and becomes a  -  1  +  stepper so the quantity can be changed right there.
// Pressing minus at quantity 1 removes the product and the normal button returns.
export function AddButton({ item, large, style }) {
  const { cart, changeQty, removeItem } = useApp();
  const add = useAdd();
  const line = cart.find((i) => i.id === item.id);
  if (!line) {
    return (
      <Btn small={!large} outline={!large} icon={large ? 'bag-add-outline' : 'add'}
        label={large ? 'Add to Cart · ' + rs(item.price) : 'Add to Cart'} onPress={() => add(item)} style={style} />
    );
  }
  const minus = () => (line.qty > 1 ? changeQty(item.id, -1) : removeItem(item.id));
  return (
    <View style={[s.stepper, large && s.stepperL, style]}>
      <TouchableOpacity style={s.stepBtn} onPress={minus} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
        <Ionicons name={line.qty > 1 ? 'remove' : 'trash-outline'} size={large ? 20 : 16} color={C.cream} />
      </TouchableOpacity>
      <Text style={[s.stepQty, large && { fontSize: 16 }]}>{large ? line.qty + ' in your cart' : line.qty}</Text>
      <TouchableOpacity style={s.stepBtn} onPress={() => changeQty(item.id, 1)} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
        <Ionicons name="add" size={large ? 20 : 16} color={C.cream} />
      </TouchableOpacity>
    </View>
  );
}

// Price display: original price cut through (if on sale) with the discounted price below it
export function PriceTag({ item, size = 14, reserve = true }) {
  return (
    <View style={{ marginTop: 6 }}>
      {item.oldPrice ? (
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Text style={{ fontSize: size - 3, color: C.mute, textDecorationLine: 'line-through' }}>{rs(item.oldPrice)}</Text>
          <View style={{ backgroundColor: C.maroon, borderRadius: 4, paddingHorizontal: 5, paddingVertical: 1, marginLeft: 6 }}>
            <Text style={{ color: C.cream, fontSize: 9, fontWeight: '700' }}>20% OFF</Text>
          </View>
        </View>
      ) : reserve ? <Text style={{ fontSize: size - 3 }}> </Text> : null}
      <Text style={{ fontSize: size, fontWeight: '800', color: C.maroon }}>{rs(item.price)}</Text>
    </View>
  );
}

export function ProductCard({ item }) {
  const nav = useNavigation();
  return (
    <TouchableOpacity activeOpacity={0.9} style={s.card} onPress={() => nav.navigate('Details', { product: item })}>
      <ProductImage item={item} style={{ width: '100%', aspectRatio: 0.85, borderRadius: 12 }} />
      <Text style={s.cardName} numberOfLines={1}>{item.name}</Text>
      <Text style={s.cardDesc} numberOfLines={2}>{item.desc}</Text>
      <PriceTag item={item} />
      <AddButton item={item} style={{ marginTop: 8 }} />
    </TouchableOpacity>
  );
}

const W = Dimensions.get('window').width;
export function Marquee({ text }) {
  const x = useRef(new Animated.Value(W)).current;
  useEffect(() => {
    const loop = Animated.loop(Animated.timing(x, { toValue: -640, duration: 11000, easing: Easing.linear, useNativeDriver: true }));
    x.setValue(W);
    loop.start();
    return () => loop.stop();
  }, []);
  return (
    <View style={s.marquee}>
      <Animated.View style={{ position: 'absolute', left: 0, transform: [{ translateX: x }] }}>
        <Text numberOfLines={1} style={s.marqueeT}>{text}</Text>
      </Animated.View>
    </View>
  );
}

export const s = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 10 },
  hBtn: { width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center' },
  hTitle: { fontSize: 12, letterSpacing: 3, color: C.maroon, fontWeight: '700' },
  badge: { position: 'absolute', top: 2, right: 0, minWidth: 16, height: 16, borderRadius: 8, backgroundColor: C.maroon, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 3 },
  badgeT: { color: C.cream, fontSize: 9, fontWeight: '700' },
  eyebrow: { fontSize: 10, letterSpacing: 2, color: C.maroonSoft, fontWeight: '700', marginBottom: 6 },
  title: { fontFamily: serif, fontSize: 30, color: C.ink, lineHeight: 36 },
  sub: { color: C.mute, fontSize: 13, marginTop: 6, lineHeight: 19 },
  btn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 14, borderRadius: 10, borderWidth: 1 },
  btnF: { backgroundColor: C.maroon, borderColor: C.maroon },
  btnO: { backgroundColor: 'transparent', borderColor: C.maroon },
  btnT: { fontSize: 14, fontWeight: '700', letterSpacing: 0.3 },
  chip: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20, borderWidth: 1, borderColor: C.line, marginRight: 8, backgroundColor: C.white },
  ring: { position: 'absolute', width: 150, height: 150, borderRadius: 75, borderWidth: 1, borderColor: 'rgba(107,29,51,0.15)' },
  card: { flex: 1, backgroundColor: C.white, borderRadius: 16, padding: 8, borderWidth: 1, borderColor: C.line },
  cardName: { fontFamily: serif, fontSize: 15, color: C.ink, marginTop: 10 },
  cardDesc: { fontSize: 11, color: C.mute, marginTop: 3, lineHeight: 15, minHeight: 30 },
  price: { fontSize: 14, fontWeight: '800', color: C.maroon, marginTop: 6 },
  stepper: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: C.maroon, borderRadius: 10, minHeight: 38, paddingHorizontal: 6 },
  stepperL: { minHeight: 52, borderRadius: 12, paddingHorizontal: 14 },
  stepBtn: { paddingHorizontal: 10, paddingVertical: 6 },
  stepQty: { color: C.cream, fontWeight: '800', fontSize: 14 },
  marquee: { height: 32, backgroundColor: C.maroon, overflow: 'hidden', justifyContent: 'center' },
  marqueeT: { width: 620, color: C.cream, fontSize: 12, fontWeight: '600', letterSpacing: 0.4 },
});