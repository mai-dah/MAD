// import { StatusBar } from 'expo-status-bar';
// import { StyleSheet, Text, View } from 'react-native';

// export default function App() {
//   return (
//     <View style={styles.container}>
//       <Text>Open up App.js to start working on your app!</Text>
//       <StatusBar style="auto" />
//     </View>
//   );
// }

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: '#fff',
//     alignItems: 'center',
//     justifyContent: 'center',
//   },
// });
import 'react-native-gesture-handler';
import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer, DefaultTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { AppProvider, useApp } from './src/context';
import { C } from './src/theme';
import * as S from './src/screens';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();
const theme = { ...DefaultTheme, colors: { ...DefaultTheme.colors, background: C.cream, primary: C.maroon } };

function Tabs() {
  const { count } = useApp();
  const icons = { Home: 'home', Discover: 'compass', Cart: 'bag', Account: 'person' };
  return (
    <Tab.Navigator screenOptions={({ route }) => ({
      headerShown: false, tabBarActiveTintColor: C.maroon, tabBarInactiveTintColor: C.mute,
      tabBarStyle: { backgroundColor: C.cream, borderTopColor: C.line, height: 62, paddingBottom: 8, paddingTop: 6 },
      tabBarBadgeStyle: { backgroundColor: C.maroon, color: C.cream },
      tabBarIcon: ({ color, focused }) => <Ionicons name={focused ? icons[route.name] : icons[route.name] + '-outline'} size={22} color={color} />,
    })}>
      <Tab.Screen name="Home" component={S.HomeScreen} />
      <Tab.Screen name="Discover" component={S.DiscoverScreen} />
      <Tab.Screen name="Cart" component={S.CartScreen} options={{ tabBarBadge: count > 0 ? count : undefined }} />
      <Tab.Screen name="Account" component={S.AccountScreen} />
    </Tab.Navigator>
  );
}

export default function App() {
  return (
    <SafeAreaProvider>
      <AppProvider>
        <NavigationContainer theme={theme}>
          <StatusBar style="dark" />
          <Stack.Navigator initialRouteName="Splash" screenOptions={{ headerShown: false, contentStyle: { backgroundColor: C.cream } }}>
            <Stack.Screen name="Splash" component={S.SplashScreen} />
            <Stack.Screen name="Tabs" component={Tabs} />
            <Stack.Screen name="Category" component={S.CategoryScreen} />
            <Stack.Screen name="Products" component={S.ProductsScreen} />
            <Stack.Screen name="Details" component={S.DetailsScreen} />
            <Stack.Screen name="Auth" component={S.AuthScreen} />
            <Stack.Screen name="Checkout" component={S.CheckoutScreen} />
            <Stack.Screen name="Feedback" component={S.FeedbackScreen} />
            <Stack.Screen name="Confirmed" component={S.ConfirmedScreen} options={{ gestureEnabled: false }} />
          </Stack.Navigator>
        </NavigationContainer>
      </AppProvider>
    </SafeAreaProvider>
  );
}