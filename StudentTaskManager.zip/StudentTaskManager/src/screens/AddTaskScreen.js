import React, { useCallback, useState } from 'react';
import { Alert, View } from 'react-native';
import TaskForm from '../components/TaskForm';
import { useTasks } from '../context/TasksContext';
import { COLORS } from '../constants/theme';

export default function AddTaskScreen({ navigation }) {
  const { addTask } = useTasks();
  const [saving, setSaving] = useState(false);

  const handleSubmit = useCallback(
    async (form) => {
      if (!form.title.trim() || !form.subject.trim()) {
        Alert.alert('Missing information', 'Task Title and Subject Name are required.');
        return false;
      }
      try {
        setSaving(true);
        await addTask(form); // saved in Firebase Firestore
        Alert.alert('Success', 'Task saved successfully!', [
          { text: 'OK', onPress: () => navigation.navigate('MyTasks') },
        ]);
        return true;
      } catch (e) {
        Alert.alert('Error', e.message);
        return false;
      } finally {
        setSaving(false);
      }
    },
    [addTask, navigation]
  );

  return (
    <View style={{ flex: 1, backgroundColor: COLORS.bg }}>
      <TaskForm submitLabel="Save Task" onSubmit={handleSubmit} saving={saving} />
    </View>
  );
}