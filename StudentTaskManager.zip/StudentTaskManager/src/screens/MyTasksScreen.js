import React, { useCallback, useMemo, useState } from 'react';
import { ActivityIndicator, Alert, FlatList, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import TaskItem from '../components/TaskItem';
import { useTasks } from '../context/TasksContext';
import { COLORS } from '../constants/theme';

const FILTERS = ['All', 'Pending', 'Completed'];

export default function MyTasksScreen({ navigation }) {
  const { tasks, loading, deleteTask, markCompleted } = useTasks();
  const [filter, setFilter] = useState('All');

  // useMemo: filtered list only recalculated when tasks or filter change
  const visibleTasks = useMemo(
    () => (filter === 'All' ? tasks : tasks.filter((t) => t.status === filter)),
    [tasks, filter]
  );

  // useCallback: stable functions passed down to <TaskItem />
  const handleEdit = useCallback((task) => navigation.navigate('EditTask', { task }), [navigation]);

  const handleComplete = useCallback(
    async (id) => {
      try {
        await markCompleted(id);
      } catch (e) {
        Alert.alert('Error', e.message);
      }
    },
    [markCompleted]
  );

  const handleDelete = useCallback(
    (task) => {
      Alert.alert('Delete Task', `Delete "${task.title}"?`, [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await deleteTask(task.id);
            } catch (e) {
              Alert.alert('Error', e.message);
            }
          },
        },
      ]);
    },
    [deleteTask]
  );

  const renderItem = useCallback(
    ({ item }) => (
      <TaskItem task={item} onEdit={handleEdit} onDelete={handleDelete} onComplete={handleComplete} />
    ),
    [handleEdit, handleDelete, handleComplete]
  );

  return (
    <View style={styles.container}>
      <View style={styles.filterRow}>
        {FILTERS.map((f) => (
          <TouchableOpacity
            key={f}
            style={[styles.chip, filter === f && styles.chipActive]}
            onPress={() => setFilter(f)}
          >
            <Text style={[styles.chipText, filter === f && styles.chipTextActive]}>{f}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {loading ? (
        <ActivityIndicator size="large" color={COLORS.primary} style={{ marginTop: 40 }} />
      ) : (
        <FlatList
          data={visibleTasks}
          keyExtractor={(item) => item.id}
          renderItem={renderItem}
          contentContainerStyle={{ padding: 16 }}
          ListEmptyComponent={<Text style={styles.empty}>No tasks found. Add one from the dashboard!</Text>}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.bg },
  filterRow: { flexDirection: 'row', gap: 8, paddingHorizontal: 16, paddingTop: 14 },
  chip: { paddingVertical: 8, paddingHorizontal: 16, borderRadius: 20, backgroundColor: '#e5e7eb' },
  chipActive: { backgroundColor: COLORS.primary },
  chipText: { color: COLORS.text, fontWeight: '600' },
  chipTextActive: { color: '#fff' },
  empty: { textAlign: 'center', color: COLORS.muted, marginTop: 40 },
});