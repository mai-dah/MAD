import React from 'react';
import { ActivityIndicator, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useTasks } from '../context/TasksContext';
import { COLORS } from '../constants/theme';

function StatCard({ label, value, color }) {
  return (
    <View style={[styles.stat, { borderLeftColor: color }]}>
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </View>
  );
}

export default function HomeScreen({ navigation }) {
  const { stats, loading, error } = useTasks();

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Student Task Manager</Text>
      <Text style={styles.sub}>Track your study tasks</Text>

      {loading ? (
        <ActivityIndicator size="large" color={COLORS.primary} style={{ marginVertical: 30 }} />
      ) : error ? (
        <Text style={styles.error}>Firebase error: {error}</Text>
      ) : (
        <View style={{ marginTop: 20 }}>
          <StatCard label="Total Tasks" value={stats.total} color={COLORS.primary} />
          <StatCard label="Completed Tasks" value={stats.completed} color={COLORS.success} />
          <StatCard label="Pending Tasks" value={stats.pending} color={COLORS.warning} />
        </View>
      )}

      <TouchableOpacity style={styles.primaryBtn} onPress={() => navigation.navigate('AddTask')}>
        <Text style={styles.primaryText}>+ Add New Task</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.secondaryBtn} onPress={() => navigation.navigate('MyTasks')}>
        <Text style={styles.secondaryText}>View My Tasks</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.bg, padding: 20 },
  heading: { fontSize: 26, fontWeight: '800', color: COLORS.text, marginTop: 10 },
  sub: { color: COLORS.muted, marginTop: 4 },
  stat: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 18,
    marginBottom: 12,
    borderLeftWidth: 6,
    elevation: 2,
  },
  statValue: { fontSize: 32, fontWeight: '800', color: COLORS.text },
  statLabel: { fontSize: 15, color: COLORS.muted, marginTop: 2 },
  primaryBtn: { backgroundColor: COLORS.primary, padding: 16, borderRadius: 12, alignItems: 'center', marginTop: 16 },
  primaryText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  secondaryBtn: {
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 12,
    borderWidth: 1.5,
    borderColor: COLORS.primary,
  },
  secondaryText: { color: COLORS.primary, fontSize: 16, fontWeight: '700' },
  error: { color: COLORS.danger, marginTop: 20 },
});