import React, { useCallback, useState } from 'react';
import { Alert, View } from 'react-native';
import TaskForm from '../components/TaskForm';
import { useTasks } from '../context/TasksContext';
import { COLORS } from '../constants/theme';

export default function EditTaskScreen({ route, navigation }) {
  const { task } = route.params;
  const { updateTask } = useTasks();
  const [saving, setSaving] = useState(false);

  const handleSubmit = useCallback(
    async (form) => {
      if (!form.title.trim() || !form.subject.trim()) {
        Alert.alert('Missing information', 'Task Title and Subject Name are required.');
        return false;
      }
      try {
        setSaving(true);
        await updateTask(task.id, form); // updated in Firebase Firestore
        Alert.alert('Success', 'Task updated successfully!', [
          { text: 'OK', onPress: () => navigation.goBack() },
        ]);
      } catch (e) {
        Alert.alert('Error', e.message);
      } finally {
        setSaving(false);
      }
      return false; // keep the edited values visible
    },
    [task.id, updateTask, navigation]
  );

  return (
    <View style={{ flex: 1, backgroundColor: COLORS.bg }}>
      <TaskForm
        initialValues={{
          title: task.title,
          subject: task.subject,
          description: task.description,
          status: task.status,
        }}
        submitLabel="Update Task"
        onSubmit={handleSubmit}
        saving={saving}
      />
    </View>
  );
}