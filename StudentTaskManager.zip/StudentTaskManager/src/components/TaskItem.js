import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { COLORS } from '../constants/theme';

function TaskItem({ task, onEdit, onDelete, onComplete }) {
  const completed = task.status === 'Completed';
  return (
    <View style={styles.card}>
      <View style={styles.header}>
        <Text style={[styles.title, completed && styles.done]} numberOfLines={2}>
          {task.title}
        </Text>
        <View style={[styles.badge, { backgroundColor: completed ? COLORS.success : COLORS.warning }]}>
          <Text style={styles.badgeText}>{task.status}</Text>
        </View>
      </View>
      <Text style={styles.subject}>Subject: {task.subject}</Text>

      <View style={styles.actions}>
        {!completed && (
          <TouchableOpacity style={[styles.btn, { backgroundColor: COLORS.success }]} onPress={() => onComplete(task.id)}>
            <Text style={styles.btnText}>Complete</Text>
          </TouchableOpacity>
        )}
        <TouchableOpacity style={[styles.btn, { backgroundColor: COLORS.primary }]} onPress={() => onEdit(task)}>
          <Text style={styles.btnText}>Edit</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.btn, { backgroundColor: COLORS.danger }]} onPress={() => onDelete(task)}>
          <Text style={styles.btnText}>Delete</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

export default React.memo(TaskItem);

const styles = StyleSheet.create({
  card: {
    backgroundColor: COLORS.card,
    borderRadius: 12,
    padding: 14,
    marginBottom: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOpacity: 0.08,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 2 },
  },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8 },
  title: { flex: 1, fontSize: 17, fontWeight: '700', color: COLORS.text },
  done: { textDecorationLine: 'line-through', color: COLORS.muted },
  badge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20 },
  badgeText: { color: '#fff', fontSize: 12, fontWeight: '700' },
  subject: { marginTop: 6, color: COLORS.muted, fontSize: 14 },
  actions: { flexDirection: 'row', gap: 8, marginTop: 12 },
  btn: { paddingVertical: 8, paddingHorizontal: 14, borderRadius: 8 },
  btnText: { color: '#fff', fontWeight: '600', fontSize: 13 },
});