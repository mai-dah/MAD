import React, { useEffect, useReducer, useRef } from 'react';
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { COLORS, STATUS } from '../constants/theme';

const emptyForm = { title: '', subject: '', description: '', status: STATUS.PENDING };

// useReducer: all form values managed in one place
function formReducer(state, action) {
  switch (action.type) {
    case 'SET_FIELD':
      return { ...state, [action.field]: action.value };
    case 'RESET':
      return { ...emptyForm, ...(action.payload || {}) };
    default:
      return state;
  }
}

export default function TaskForm({ initialValues, submitLabel, onSubmit, saving }) {
  const [form, dispatch] = useReducer(formReducer, { ...emptyForm, ...initialValues });

  // useRef: direct access to the inputs
  const titleRef = useRef(null);
  const subjectRef = useRef(null);
  const descriptionRef = useRef(null);

  // Auto-focus the Task Title field when the screen opens
  useEffect(() => {
    const t = setTimeout(() => titleRef.current?.focus(), 300);
    return () => clearTimeout(t);
  }, []);

  const setField = (field) => (value) => dispatch({ type: 'SET_FIELD', field, value });

  const handleSubmit = async () => {
    const ok = await onSubmit(form);
    if (ok) dispatch({ type: 'RESET' });
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
        <Text style={styles.label}>Task Title *</Text>
        <TextInput
          ref={titleRef}
          style={styles.input}
          placeholder="e.g. Finish Chapter 5 notes"
          value={form.title}
          onChangeText={setField('title')}
          returnKeyType="next"
          onSubmitEditing={() => subjectRef.current?.focus()}
        />

        <Text style={styles.label}>Subject Name *</Text>
        <TextInput
          ref={subjectRef}
          style={styles.input}
          placeholder="e.g. Mobile App Development"
          value={form.subject}
          onChangeText={setField('subject')}
          returnKeyType="next"
          onSubmitEditing={() => descriptionRef.current?.focus()}
        />

        <Text style={styles.label}>Description</Text>
        <TextInput
          ref={descriptionRef}
          style={[styles.input, styles.multiline]}
          placeholder="Write task details..."
          value={form.description}
          onChangeText={setField('description')}
          multiline
          numberOfLines={4}
          textAlignVertical="top"
        />

        <Text style={styles.label}>Status</Text>
        <View style={styles.statusRow}>
          {[STATUS.PENDING, STATUS.COMPLETED].map((s) => {
            const active = form.status === s;
            return (
              <TouchableOpacity
                key={s}
                style={[styles.statusBtn, active && styles.statusBtnActive]}
                onPress={() => dispatch({ type: 'SET_FIELD', field: 'status', value: s })}
              >
                <Text style={[styles.statusText, active && styles.statusTextActive]}>{s}</Text>
              </TouchableOpacity>
            );
          })}
        </View>

        <TouchableOpacity
          style={[styles.submit, saving && { opacity: 0.6 }]}
          onPress={handleSubmit}
          disabled={saving}
        >
          {saving ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.submitText}>{submitLabel}</Text>
          )}
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20 },
  label: { fontSize: 14, fontWeight: '600', color: COLORS.text, marginBottom: 6, marginTop: 14 },
  input: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 15,
  },
  multiline: { minHeight: 100 },
  statusRow: { flexDirection: 'row', gap: 10 },
  statusBtn: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: COLORS.border,
    backgroundColor: '#fff',
    alignItems: 'center',
  },
  statusBtnActive: { backgroundColor: COLORS.primary, borderColor: COLORS.primary },
  statusText: { color: COLORS.text, fontWeight: '600' },
  statusTextActive: { color: '#fff' },
  submit: {
    backgroundColor: COLORS.primary,
    paddingVertical: 14,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 28,
  },
  submitText: { color: '#fff', fontWeight: '700', fontSize: 16 },
});