import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  updateDoc,
} from 'firebase/firestore';
import { db } from '../firebase';

const TasksContext = createContext(null);
const tasksRef = collection(db, 'tasks');

export function TasksProvider({ children }) {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // READ: real-time listener
  useEffect(() => {
    const q = query(tasksRef, orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        setTasks(snapshot.docs.map((d) => ({ id: d.id, ...d.data() })));
        setLoading(false);
      },
      (err) => {
        setError(err.message);
        setLoading(false);
      }
    );
    return unsubscribe;
  }, []);

  // CREATE (useCallback)
  const addTask = useCallback(async ({ title, subject, description, status }) => {
    await addDoc(tasksRef, {
      title: title.trim(),
      subject: subject.trim(),
      description: description.trim(),
      status,
      createdAt: serverTimestamp(),
    });
  }, []);

  // UPDATE: full edit (useCallback)
  const updateTask = useCallback(async (id, { title, subject, description, status }) => {
    await updateDoc(doc(db, 'tasks', id), {
      title: title.trim(),
      subject: subject.trim(),
      description: description.trim(),
      status,
      updatedAt: serverTimestamp(),
    });
  }, []);

  // UPDATE: quick "mark completed" (useCallback)
  const markCompleted = useCallback(async (id) => {
    await updateDoc(doc(db, 'tasks', id), {
      status: 'Completed',
      updatedAt: serverTimestamp(),
    });
  }, []);

  // DELETE (useCallback)
  const deleteTask = useCallback(async (id) => {
    await deleteDoc(doc(db, 'tasks', id));
  }, []);

  // useMemo: counts recalculate only when `tasks` changes
  const stats = useMemo(() => {
    const completed = tasks.filter((t) => t.status === 'Completed').length;
    return {
      total: tasks.length,
      completed,
      pending: tasks.length - completed,
    };
  }, [tasks]);

  const value = useMemo(
    () => ({ tasks, loading, error, stats, addTask, updateTask, markCompleted, deleteTask }),
    [tasks, loading, error, stats, addTask, updateTask, markCompleted, deleteTask]
  );

  return <TasksContext.Provider value={value}>{children}</TasksContext.Provider>;
}

export const useTasks = () => {
  const ctx = useContext(TasksContext);
  if (!ctx) throw new Error('useTasks must be used inside <TasksProvider>');
  return ctx;
};