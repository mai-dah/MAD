export const COLORS = {
  primary: '#4f46e5',
  bg: '#f3f4f6',
  card: '#ffffff',
  text: '#111827',
  muted: '#6b7280',
  border: '#d1d5db',
  success: '#16a34a',
  warning: '#d97706',
  danger: '#dc2626',
};

export const STATUS = {
  PENDING: 'Pending',
  COMPLETED: 'Completed',
};