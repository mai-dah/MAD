import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyCiMb7ER4jONs-PgQG2j98MQnuEmdNqWM4",
  authDomain: "studenttaskmanager-27fb3.firebaseapp.com",
  projectId: "studenttaskmanager-27fb3",
  storageBucket: "studenttaskmanager-27fb3.firebasestorage.app",
  messagingSenderId: "11503142380",
  appId: "1:11503142380:web:543fc5297dc840ee1cecc9"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);