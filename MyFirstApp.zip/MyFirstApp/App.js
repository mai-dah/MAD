// ============================================================
// OLD PRACTICE CODE - NOT CURRENTLY USED
// ============================================================

// import { StatusBar } from 'expo-status-bar';
// import { StyleSheet, Text, View } from 'react-native';

// export default function App() {
//   return (
//     <View style={styles.container}>
//       <Text>Open up App.js to start working on your app!</Text>
//       <StatusBar style="auto" />
//     </View>
//   );
// }

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: '#fff',
//     alignItems: 'center',
//     justifyContent: 'center',
//   },
// // });


// ============================================================
// OLD PRACTICE CODE - SIMPLE APP
// ============================================================

// import React from "react";
// import { View, Text } from "react-native";

// function App() {
//   return (
//     <View>
//       <Text>Hello Mobile App</Text>
//     </View>
//   );
// }

// export default App;


// ============================================================
// OLD PRACTICE CODE - DISPLAYING SCREENS
// ============================================================

// import { View } from "react-native";
// import HomeScreen from "./frontend/HomeScreen";
// import ProfileScreen from "./frontend/ProfileScreen";

// export default function App() {
//   return (
//     <View>
//       <HomeScreen />
//       <ProfileScreen />
//     </View>
//   );
// }


// ============================================================
// OLD PRACTICE CODE - PROPS EXAMPLE
// ============================================================

// import { View } from "react-native";
// import HomeScreen from "./frontend/HomeScreen";
// import ProfileScreen from "./frontend/ProfileScreen";

// export default function App() {
//   return (
//     <View>

//       <HomeScreen
//         name="Kausar"
//         program="Artificial Intelligence"
//         semester={4}
//       />

//       <ProfileScreen
//         university="ABC University"
//         department="AI"
//         city="Islamabad"
//       />

//     </View>
//   );
// }


// ============================================================
// CURRENT METHOD: REACT NAVIGATION
// ============================================================

import React from 'react';

import {
  NavigationContainer
} from '@react-navigation/native';

import {
  createNativeStackNavigator
} from '@react-navigation/native-stack';


// Import all screens
import HomeScreen from './frontend/screens/HomeScreen';
import ProfileScreen from './frontend/screens/ProfileScreen';
import SettingsScreen from './frontend/screens/SettingsScreen';
import ContactScreen from './frontend/screens/ContactScreen';


// Create the Stack Navigator
const Stack = createNativeStackNavigator();


export default function App() {

  return (
    // NavigationContainer manages navigation in the app
    <NavigationContainer>

      {/* Stack.Navigator contains all screens/routes */}
      <Stack.Navigator>

        {/* Home route */}
        <Stack.Screen
          name="Home"
          component={HomeScreen}
          options={{ title: 'Student App' }}
        />

        {/* Profile route */}
        <Stack.Screen
          name="Profile"
          component={ProfileScreen}
        />

        {/* Settings route */}
        <Stack.Screen
          name="Settings"
          component={SettingsScreen}
        />

        {/* Contact route */}
        <Stack.Screen
          name="Contact"
          component={ContactScreen}
        />

      </Stack.Navigator>

    </NavigationContainer>
  );
}


// ============================================================
// ALTERNATIVE METHOD: PROPS + STATE
// CURRENTLY COMMENTED OUT
// ============================================================

// import React, { useState } from 'react';

// import HomeScreen from './frontend/screens/HomeScreen';
// import ProfileScreen from './frontend/screens/ProfileScreen';
// import SettingsScreen from './frontend/screens/SettingsScreen';
// import ContactScreen from './frontend/screens/ContactScreen';

// export default function App() {

//   // State stores which screen should be displayed
//   const [screen, setScreen] = useState('home');

//   // Show Profile Screen
//   if (screen === 'profile') {
//     return (
//       <ProfileScreen
//         // goToHome is passed to ProfileScreen as a PROP
//         goToHome={() => setScreen('home')}
//       />
//     );
//   }

//   // Show Settings Screen
//   if (screen === 'settings') {
//     return (
//       <SettingsScreen
//         // goToHome is passed to SettingsScreen as a PROP
//         goToHome={() => setScreen('home')}
//       />
//     );
//   }

//   // Show Contact Screen
//   if (screen === 'contact') {
//     return (
//       <ContactScreen
//         // goToHome is passed to ContactScreen as a PROP
//         goToHome={() => setScreen('home')}
//       />
//     );
//   }

//   // Show Home Screen
//   return (
//     <HomeScreen
//       // These functions are passed as PROPS
//       goToProfile={() => setScreen('profile')}
//       goToSettings={() => setScreen('settings')}
//       goToContact={() => setScreen('contact')}
//     />
//   );
// }