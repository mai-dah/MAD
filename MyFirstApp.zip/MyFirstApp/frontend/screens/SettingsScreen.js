// ============================================================
// CURRENT METHOD: REACT NAVIGATION
// ============================================================

import React, { useState } from 'react';

import {
  TouchableOpacity,
  View,
  Text,
  Switch,
  StyleSheet,
} from 'react-native';

import globalStyles from '../globalStyles';


// navigation is automatically provided by React Navigation
export default function SettingsScreen({ navigation }) {


// ============================================================
// ALTERNATIVE: PROPS + STATE
// CURRENTLY COMMENTED OUT
// ============================================================

// export default function SettingsScreen({ goToHome }) {


  // State stores whether Dark Mode is ON or OFF
  const [darkMode, setDarkMode] = useState(false);


  return (
    <View
      style={[
        globalStyles.container,
        darkMode ? styles.darkContainer : styles.lightContainer
      ]}
    >

      <Text
        style={[
          globalStyles.title,
          darkMode && styles.darkText
        ]}
      >
        Settings
      </Text>


      {/* Dark Mode setting */}
      <View style={styles.settingRow}>

        <Text
          style={[
            globalStyles.subtitle,
            darkMode && styles.darkText
          ]}
        >
          Dark Mode
        </Text>


        {/* Switch changes the darkMode state */}
        <Switch
          value={darkMode}
          onValueChange={setDarkMode}
        />

      </View>


      {/* Shows current mode */}
      <Text
        style={[
          styles.status,
          darkMode && styles.darkText
        ]}
      >
        {darkMode ? 'Dark Mode is ON' : 'Light Mode is ON'}
      </Text>


      {/* ==================================================
          BACK BUTTON - REACT NAVIGATION
          ================================================== */}

      <TouchableOpacity
        style={globalStyles.button}
        onPress={() => navigation.navigate('Home')}

        // PROPS + STATE alternative:
        // onPress={goToHome}
      >
        <Text style={globalStyles.buttonText}>
          Back to Home
        </Text>
      </TouchableOpacity>

    </View>
  );
}


// ============================================================
// LOCAL STYLES
// ============================================================

const styles = StyleSheet.create({

  lightContainer: {
    backgroundColor: '#F5F5F5',
  },

  darkContainer: {
    backgroundColor: '#222222',
  },

  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '90%',
    padding: 20,
    borderRadius: 10,
    backgroundColor: '#DDDDDD',
  },

  darkText: {
    color: 'white',
  },

  status: {
    fontSize: 18,
    marginTop: 30,
  },

});


// ============================================================
// OLD PROPS + STATE VERSION - CURRENTLY COMMENTED OUT
// ============================================================

// import React, { useState } from 'react';

// import {
//   View,
//   Text,
//   Switch,
//   TouchableOpacity,
//   StyleSheet,
// } from 'react-native';

// import globalStyles from '../globalStyles';

// export default function SettingsScreen({ goToHome }) {

//   const [darkMode, setDarkMode] = useState(false);

//   return (
//     <View
//       style={[
//         globalStyles.container,
//         darkMode
//           ? styles.darkContainer
//           : styles.lightContainer
//       ]}
//     >

//       <Text
//         style={[
//           globalStyles.title,
//           darkMode ? styles.darkText : styles.lightText
//         ]}
//       >
//         Settings
//       </Text>

//       <View
//         style={[
//           styles.settingRow,
//           darkMode && styles.darkRow
//         ]}
//       >

//         <Text
//           style={[
//             styles.settingText,
//             darkMode ? styles.darkText : styles.lightText
//           ]}
//         >
//           Dark Mode
//         </Text>

//         <Switch
//           value={darkMode}
//           onValueChange={(value) => setDarkMode(value)}
//         />

//       </View>

//       <Text
//         style={[
//           styles.status,
//           darkMode ? styles.darkText : styles.lightText
//         ]}
//       >
//         {darkMode ? 'Dark Mode is ON' : 'Light Mode is ON'}
//       </Text>

//       <TouchableOpacity
//         style={globalStyles.button}
//         onPress={goToHome}
//       >
//         <Text style={globalStyles.buttonText}>
//           Back to Home
//         </Text>
//       </TouchableOpacity>

//     </View>
//   );
// }

// const styles = StyleSheet.create({

//   lightContainer: {
//     backgroundColor: '#F5F5F5',
//   },

//   darkContainer: {
//     backgroundColor: '#222222',
//   },

//   settingRow: {
//     flexDirection: 'row',
//     alignItems: 'center',
//     justifyContent: 'space-between',
//     width: '90%',
//     padding: 20,
//     borderRadius: 10,
//     backgroundColor: '#DDDDDD',
//     marginBottom: 20,
//   },

//   darkRow: {
//     backgroundColor: '#444444',
//   },

//   settingText: {
//     fontSize: 20,
//   },

//   lightText: {
//     color: '#222222',
//   },

//   darkText: {
//     color: 'white',
//   },

//   status: {
//     fontSize: 18,
//     marginBottom: 30,
//   },

// });