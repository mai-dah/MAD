// ============================================================
// OLD PRACTICE CODE - NOT CURRENTLY USED
// ============================================================

// import { View, Text } from "react-native";

// export default function ProfileScreen() {
//   return (
//     <View>
//       <Text>My Profile</Text>
//       <Text>University: Riphah University</Text>
//       <Text>Department: AI</Text>
//       <Text>Semester: 4</Text>
//     </View>
//   );
// }


// ============================================================
// OLD PRACTICE CODE - PROPS + STATE EXAMPLE
// ============================================================

// import { View, Text, Button } from "react-native";
// import { useState } from "react";

// export default function ProfileScreen(props) {

//   const [showDetails, setShowDetails] = useState(false);

//   return (
//     <View>
//       <Text>My Profile</Text>

//       <Button
//         title="Show / Hide Details"
//         onPress={() => setShowDetails(!showDetails)}
//       />

//       {showDetails && (
//         <>
//           <Text>University: {props.university}</Text>
//           <Text>Department: {props.department}</Text>
//           <Text>City: {props.city}</Text>
//         </>
//       )}

//     </View>
//   );
// }


// ============================================================
// CURRENT METHOD: REACT NAVIGATION
// ============================================================

import React, { useState } from 'react';

import {
  TouchableOpacity,
  View,
  Text,
  TextInput,
  Image,
  StyleSheet,
} from 'react-native';

import globalStyles from '../globalStyles';


// navigation is automatically provided by React Navigation
export default function ProfileScreen({ navigation }) {


// ============================================================
// ALTERNATIVE: PROPS + STATE
// CURRENTLY COMMENTED OUT
// ============================================================

// export default function ProfileScreen({ goToHome }) {


  // State for storing the user's name
  const [name, setName] = useState('');

  // State for storing the user's age
  const [age, setAge] = useState('');


  return (
    <View style={globalStyles.container}>

      {/* Online profile image */}
      <Image
  source={{
    uri: 'https://randomuser.me/api/portraits/women/44.jpg'
  }}
  style={globalStyles.profileImage}
/>

      <Text style={globalStyles.title}>
        My Profile
      </Text>


      {/* Name input */}
      <TextInput
        style={globalStyles.input}
        placeholder="Enter your name"
        value={name}
        onChangeText={setName}
        keyboardType="default"
        inputMode="text"
      />


      {/* Age input */}
      <TextInput
        style={globalStyles.input}
        placeholder="Enter your age"
        value={age}
        onChangeText={setAge}
        keyboardType="numeric"
        inputMode="numeric"
      />


      {/* Display entered information */}
      <View style={styles.dataBox}>

        <Text style={styles.dataText}>
          Name: {name}
        </Text>

        <Text style={styles.dataText}>
          Age: {age}
        </Text>

      </View>


      {/* ==================================================
          BACK BUTTON - REACT NAVIGATION
          ================================================== */}

      <TouchableOpacity
        style={globalStyles.button}
        onPress={() => navigation.navigate('Home')}

        // PROPS + STATE alternative:
        // onPress={goToHome}
      >
        <Text style={globalStyles.buttonText}>
          Back to Home
        </Text>
      </TouchableOpacity>

    </View>
  );
}


// ============================================================
// LOCAL STYLES
// ============================================================

const styles = StyleSheet.create({

  dataBox: {
    marginTop: 20,
    padding: 20,
    width: '90%',
    borderRadius: 10,
    backgroundColor: '#E8EDFF',
  },

  dataText: {
    fontSize: 18,
    marginVertical: 5,
  },

});