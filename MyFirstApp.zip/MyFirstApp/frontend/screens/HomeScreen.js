// ============================================================
// OLD PRACTICE CODE - NOT CURRENTLY USED
// ============================================================

// import { View, Text } from "react-native";

// export default function HomeScreen() {
//   return (
//     <View>
//       <Text>Welcome to Student App</Text>
//       <Text>Name: Kausar</Text>
//       <Text>Program: Artificial Intelligence</Text>
//       <Text>Semester: 4</Text>
//     </View>
//   );
// }


// ============================================================
// OLD PRACTICE CODE - PROPS EXAMPLE
// ============================================================

// import { View, Text } from "react-native";

// export default function HomeScreen(props) {
//   return (
//     <View style={{ paddingTop: 40 }}>
//       <Text>Welcome to Student App</Text>
//       <Text>Name: {props.name}</Text>
//       <Text>Program: {props.program}</Text>
//       <Text>Semester: {props.semester}</Text>
//     </View>
//   );
// }


// ============================================================
// CURRENT METHOD: REACT NAVIGATION
// ============================================================

import React from 'react';

import {
  View,
  Text,
  ImageBackground,
  TouchableOpacity,
  Button,
  StyleSheet,
} from 'react-native';

import globalStyles from '../globalStyles';


// navigation is automatically provided by React Navigation
export default function HomeScreen({ navigation }) {


// ============================================================
// ALTERNATIVE: PROPS + STATE
// CURRENTLY COMMENTED OUT
// ============================================================

// export default function HomeScreen({
//   goToProfile,
//   goToSettings,
//   goToContact
// }) {


  return (

    // ImageBackground is used for the Home screen background
    <ImageBackground
      source={{
        uri: 'https://images.unsplash.com/photo-1497366754035-f200968a6e72'
      }}
      style={styles.background}
    >

      <View style={styles.overlay}>

        <Text style={styles.title}>
          Student App
        </Text>

        <Text style={globalStyles.subtitle}>
          Welcome to My Student App
        </Text>


        {/* ==================================================
            PROFILE BUTTON - REACT NAVIGATION
            ================================================== */}

        <TouchableOpacity
          style={globalStyles.button}
          onPress={() => navigation.navigate('Profile')}

          // PROPS + STATE alternative:
          // onPress={goToProfile}
        >
          <Text style={globalStyles.buttonText}>
            Go to Profile
          </Text>
        </TouchableOpacity>


        {/* ==================================================
            SETTINGS BUTTON - REACT NAVIGATION
            ================================================== */}

        <TouchableOpacity
          style={globalStyles.button}
          onPress={() => navigation.navigate('Settings')}

          // PROPS + STATE alternative:
          // onPress={goToSettings}
        >
          <Text style={globalStyles.buttonText}>
            Go to Settings
          </Text>
        </TouchableOpacity>


        {/* ==================================================
            CONTACT BUTTON - REACT NAVIGATION
            ================================================== */}

        <View style={styles.normalButton}>

          <Button
            title="Go to Contact"
            onPress={() => navigation.navigate('Contact')}

            // PROPS + STATE alternative:
            // onPress={goToContact}
          />

        </View>

      </View>

    </ImageBackground>
  );
}


// ============================================================
// LOCAL STYLES
// ============================================================

const styles = StyleSheet.create({

  background: {
    flex: 1,
  },

  overlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: 'rgba(255,255,255,0.75)',
  },

  title: {
    fontSize: 40,
    fontWeight: 'bold',
    marginBottom: 15,
    fontFamily: 'serif',
  },

  normalButton: {
    width: '80%',
    marginTop: 8,
  },

});