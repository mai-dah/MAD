// ============================================================
// CURRENT METHOD: REACT NAVIGATION
// ============================================================

import React, { useState } from 'react';

import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Alert,
  StyleSheet,
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

import globalStyles from '../globalStyles';


// navigation is automatically provided by React Navigation
export default function ContactScreen({ navigation }) {


// ============================================================
// ALTERNATIVE: PROPS + STATE
// CURRENTLY COMMENTED OUT
// ============================================================

// export default function ContactScreen({ goToHome }) {


  // State stores the email entered by the user
  const [email, setEmail] = useState('');


  // ==========================================================
  // SUBMIT FUNCTION
  // This part is the SAME in both navigation methods.
  // It is not related to navigation.
  // ==========================================================

  const submitEmail = () => {

    // Check if email field is empty
    if (email === '') {

      Alert.alert(
        'Error',
        'Please enter your email.'
      );

    } else {

      // Show success message
      Alert.alert(
        'Success',
        'Your email has been submitted!'
      );

    }
  };


  return (
    <View style={globalStyles.container}>

      <Text style={globalStyles.title}>
        Contact Us
      </Text>


      {/* ==================================================
          EMAIL INPUT
          ================================================== */}

      <View style={styles.inputContainer}>

        {/* Email icon */}
        <Ionicons
          name="mail-outline"
          size={24}
          color="#555"
          style={styles.icon}
        />

        {/* Email TextInput */}
        <TextInput
          style={styles.emailInput}
          placeholder="Enter your email"
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
          inputMode="email"
        />

      </View>


      {/* ==================================================
          SUBMIT BUTTON
          SAME IN BOTH METHODS
          ================================================== */}

      <TouchableOpacity
        style={globalStyles.button}
        onPress={submitEmail}
      >
        <Text style={globalStyles.buttonText}>
          Submit
        </Text>
      </TouchableOpacity>


      {/* ==================================================
          BACK TO HOME - REACT NAVIGATION
          ================================================== */}

      <TouchableOpacity
        style={globalStyles.button}
        onPress={() => navigation.navigate('Home')}

        // PROPS + STATE alternative:
        // onPress={goToHome}
      >
        <Text style={globalStyles.buttonText}>
          Back to Home
        </Text>
      </TouchableOpacity>


      {/* ==================================================
          OLD COMMENTED CODE
          ================================================== */}

      {/*
      <TouchableOpacity
        style={globalStyles.button}
        onPress={submitEmail}
      >
        <Text style={globalStyles.buttonText}>
          Submit
        </Text>
      </TouchableOpacity>
      */}


    </View>
  );
}


// ============================================================
// LOCAL STYLES
// ============================================================

const styles = StyleSheet.create({

  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '90%',
    height: 50,
    borderWidth: 1,
    borderColor: '#777',
    borderRadius: 10,
    backgroundColor: 'white',
    marginBottom: 20,
    paddingHorizontal: 10,
  },

  icon: {
    marginRight: 10,
  },

  emailInput: {
    flex: 1,
    fontSize: 16,
  },

});