import { StyleSheet } from 'react-native';


// ============================================================
// GLOBAL STYLES
// These styles can be used by all screens.
// ============================================================

const globalStyles = StyleSheet.create({

  // Common screen container
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },


  // Main heading
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 30,
    textAlign: 'center',
  },


  // Subtitle
  subtitle: {
    fontSize: 20,
    marginBottom: 15,
    textAlign: 'center',
  },


  // Common input style
  input: {
    width: '90%',
    height: 50,
    borderWidth: 1,
    borderColor: '#777',
    borderRadius: 10,
    paddingHorizontal: 15,
    marginBottom: 15,
    backgroundColor: 'white',
    fontSize: 16,
  },


  // Common button style
  button: {
    width: '80%',
    padding: 15,
    borderRadius: 10,
    backgroundColor: '#4A6CF7',
    marginVertical: 8,
    alignItems: 'center',
  },


  // Button text
  buttonText: {
    color: 'white',
    fontSize: 17,
    fontWeight: 'bold',
  },


  // Profile image
  profileImage: {
    width: 150,
    height: 150,
    borderRadius: 75,
    marginBottom: 25,
  },

});


export default globalStyles;